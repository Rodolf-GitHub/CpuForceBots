local X = {}
local bot = GetBot()

local J = require( GetScriptDirectory()..'/FunLib/jmz_func')
local ConversionMode = dofile( GetScriptDirectory()..'/AuxiliaryScript/BotlibConversion') --引入技能文件
local Minion = dofile( GetScriptDirectory()..'/FunLib/Minion')
local sTalentList = J.Skill.GetTalentList(bot)
local sAbilityList = J.Skill.GetAbilityList(bot)

--编组技能、天赋、装备
local tGroupedDataList = {
}
--默认数据
local tDefaultGroupedData = {
	['Talent'] = {
		['t25'] = {10, 0},
		['t20'] = {0, 10},
		['t15'] = {10, 0},
		['t10'] = {10, 10},
	},
	['Ability'] = {2,1,1,2,2,6,1,1,2,3,6,3,3,3,6},
	['Buy'] = {
		"两个树之祭祀", -- 'item_double_tango',
		"两个魔法芒果", -- 'item_double_enchanted_mango',
		"魔法芒果", -- 'item_enchanted_mango',
		"魔杖",  -- 'item_magic_wand',
		"相位鞋", -- 'item_phase_boots',
		"先锋盾", -- 'item_vanguard',
		"阿托斯之棍", -- 'item_rod_of_atos',
		"黑皇杖", -- 'item_black_king_bar',
		"刃甲", -- 'item_blade_mail',
		"天堂之戟", -- 'item_heavens_halberd',
		"深渊之刃",  -- 'item_abyssal_blade',
		"阿哈利姆神杖", -- 'item_ultimate_scepter',
		"清莲宝珠", -- 'item_lotus_orb',
		"邪恶镰刀", -- 'item_sheepstick',
	},
	['Sell'] = {
		"强袭胸甲", -- 'item_assault',
		"先锋盾", -- -- 'item_vanguard',
	}
}

--根据组数据生成技能、天赋、装备
local nAbilityBuildList, nTalentBuildList;

nAbilityBuildList, nTalentBuildList, X['sBuyList'], X['sSellList'] = ConversionMode.Combination(tGroupedDataList, tDefaultGroupedData, true)

nAbilityBuildList,nTalentBuildList,X['sBuyList'],X['sSellList'] = J.SetUserHeroInit(nAbilityBuildList,nTalentBuildList,X['sBuyList'],X['sSellList']);

X['sSkillList'] = J.Skill.GetSkillList(sAbilityList, nAbilityBuildList, sTalentList, nTalentBuildList)

X['bDeafaultAbility'] = false
X['bDeafaultItem'] = true

function X.MinionThink(hMinionUnit)

	if Minion.IsValidUnit(hMinionUnit) 
	then
		if hMinionUnit:IsIllusion() 
		then 
			Minion.IllusionThink(hMinionUnit)	
		end
	end

end

function X.SkillsComplement()

	--如果当前英雄无法使用技能或英雄处于隐形状态，则不做操作。
	if J.CanNotUseAbility(bot) or bot:IsInvisible() then return end
	--技能检查顺序
	local order = {'R','W','Q'}
	--委托技能处理函数接管
	if ConversionMode.Skills(order) then return; end

end

return X