----------------------------------------------------------------------------------------------------
--- The Creation Come From: BOT EXPERIMENT Credit:FURIOUSPUPPY
--- BOT EXPERIMENT Author: Arizona Fauzie 2018.11.21
--- Link:http://steamcommunity.com/sharedfiles/filedetails/?id=837040016
--- Refactor: 决明子 Email: dota2jmz@163.com 微博@Dota2_决明子
--- Link:http://steamcommunity.com/sharedfiles/filedetails/?id=1573671599
--- Link:http://steamcommunity.com/sharedfiles/filedetails/?id=1627071163
----------------------------------------------------------------------------------------------------
local X = {}
local bDebugMode = ( 1 == 10 )
local bot = GetBot()

local J = require( GetScriptDirectory()..'/FunLib/jmz_func' )
local Minion = dofile( GetScriptDirectory()..'/FunLib/Minion')

local utils = require( GetScriptDirectory().."/util")
local mutil = require(GetScriptDirectory().."/MyUtility")

local sTalentList = J.Skill.GetTalentList( bot )
local sAbilityList = J.Skill.GetAbilityList( bot )
local sOutfitType = J.Item.GetOutfitType( bot )

local tTalentTreeList = {
						['t25'] = {10, 0},
						['t20'] = {10, 0},
						['t15'] = {0, 10},
						['t10'] = {0, 10},
}

local tAllAbilityBuildList = {
						{2,3,1,2,2,6,2,3,3,3,6,1,1,1,6},
						{2,3,2,3,2,6,2,1,3,3,6,1,1,1,6},
}

local nAbilityBuildList = J.Skill.GetRandomBuild( tAllAbilityBuildList )

local nTalentBuildList = J.Skill.GetTalentBuild( tTalentTreeList )

local sRandomItem_1 = RandomInt( 1, 9 ) > 6 and "item_black_king_bar" or "item_heavens_halberd"

local tOutFitList = {}

tOutFitList['outfit_carry'] = {

	"item_bristleback_outfit",
	-- "item_aghanims_shard",
	"item_basher",
	"item_blade_mail",
	"item_abyssal_blade",
		
	"item_mjollnir",
	"item_blink",
	-- "item_voodoo_mask",
	-- "item_ultimate_scepter",
	-- "item_lotus_orb",
	-- "item_eternal_shroud",
	"item_travel_boots",
	sRandomItem_1,
	"item_moon_shard",
	"item_travel_boots_2",
	-- 'item_assault',
	'item_monkey_king_bar',
	-- "item_ultimate_scepter_2",
	


}

tOutFitList['outfit_mid'] = tOutFitList['outfit_carry']

tOutFitList['outfit_priest'] = tOutFitList['outfit_carry']

tOutFitList['outfit_mage'] = tOutFitList['outfit_carry']

tOutFitList['outfit_tank'] = {

	"item_tank_outfit",
	-- "item_blade_mail",
	-- "item_aghanims_shard",
	"item_crimson_guard",
	-- "item_heavens_halberd",
	-- "item_lotus_orb",
	"item_assault",
	"item_blink",
	"item_travel_boots", 
	"item_heart",
	"item_moon_shard",
	"item_travel_boots_2",
	-- "item_ultimate_scepter_2",
	"item_sheepstick",


}

X['sBuyList'] = tOutFitList[sOutfitType]

X['sSellList'] = {

	"item_power_treads",
	"item_quelling_blade",

	"item_assault",
	"item_magic_wand",
	"item_blade_mail",
	"item_travel_boots",
	"item_magic_wand",

	"item_assault",
	"item_ancient_janggo",
}

if J.Role.IsPvNMode() or J.Role.IsAllShadow() then X['sBuyList'], X['sSellList'] = { 'PvN_tank' }, {"item_power_treads", 'item_quelling_blade'} end

nAbilityBuildList, nTalentBuildList, X['sBuyList'], X['sSellList'] = J.SetUserHeroInit( nAbilityBuildList, nTalentBuildList, X['sBuyList'], X['sSellList'] )

X['sSkillList'] = J.Skill.GetSkillList( sAbilityList, nAbilityBuildList, sTalentList, nTalentBuildList )

X['bDeafaultAbility'] = false
X['bDeafaultItem'] = false

function X.MinionThink( hMinionUnit )

	if Minion.IsValidUnit( hMinionUnit )
	then
		Minion.IllusionThink( hMinionUnit )
	end

end

--[[

npc_dota_hero_bristleback

"Ability1"		"bristleback_viscous_nasal_goo"
"Ability2"		"bristleback_quill_spray"
"Ability3"		"bristleback_bristleback"
"Ability4"		"generic_hidden"
"Ability5"		"generic_hidden"
"Ability6"		"bristleback_warpath"
"Ability10"		"special_bonus_movement_speed_20"
"Ability11"		"special_bonus_mp_regen_3"
"Ability12"		"special_bonus_hp_250"
"Ability13"		"special_bonus_unique_bristleback"
"Ability14"		"special_bonus_hp_regen_25"
"Ability15"		"special_bonus_unique_bristleback_2"
"Ability16"		"special_bonus_spell_lifesteal_15"
"Ability17"		"special_bonus_unique_bristleback_3"

modifier_bristleback_viscous_nasal_goo
modifier_bristleback_quillspray_thinker
modifier_bristleback_quill_spray
modifier_bristleback_quill_spray_stack
modifier_bristleback_bristleback
modifier_bristleback_warpath
modifier_bristleback_warpath_stack

--]]

local abilityQ = bot:GetAbilityByName( sAbilityList[1] )
local abilityW = bot:GetAbilityByName( sAbilityList[2] )
local abilityE = bot:GetAbilityByName( sAbilityList[3] )
local abilityR = bot:GetAbilityByName( sAbilityList[6] )


local castQDesire, castQTarget
local castWDesire, castWTarget
local castEDesire, castETarget
local castRDesire

local nKeepMana, nMP, nHP, nLV, hEnemyList, botTarget,lastCheck


function X.SkillsComplement()


	if J.CanNotUseAbility( bot ) or bot:IsInvisible() then return end


	nKeepMana = 180
	nMP = bot:GetMana()/bot:GetMaxMana()
	nHP = bot:GetHealth()/bot:GetMaxHealth()
	nLV = bot:GetLevel()
	botTarget = J.GetProperTarget( bot )
	hEnemyList = bot:GetNearbyHeroes( 1600, true, BOT_MODE_NONE )
	lastCheck = -90;

	
	
	
	castQDesire, castQTarget = X.ConsiderQ()
	if ( castQDesire > 0 )
	then

		J.SetQueuePtToINT( bot, true )

		bot:ActionQueue_UseAbilityOnEntity( abilityQ, castQTarget )
		
		return
	end
	
	
	
	castWDesire, castWTarget = X.ConsiderW()
	if ( castWDesire > 0 )
	then

		-- J.SetQueuePtToINT( bot, true )
		bot:Action_ClearActions( true )
		bot:ActionQueue_UseAbilityOnEntity( abilityW, castWTarget )
		bot:ActionQueue_UseAbilityOnLocation( nil, castWTarget:GetLocation() )
		
		bot:Action_Delay( 0.25 )

		return
	end
	
	
	castEDesire, castETarget = X.ConsiderE()
	if ( castEDesire > 0 )
	then

		J.SetQueuePtToINT( bot, false )
	
		bot:ActionQueue_UseAbilityOnEntity( abilityE, castETarget )

		return
	end
	
	

	castRDesire = X.ConsiderR()
	if ( castRDesire > 0 )
	then

		J.SetQueuePtToINT( bot, true )

		bot:ActionQueue_UseAbility( abilityR )
		return
	end
	
	
	
	


end


function X.ConsiderQ()

	if ( not abilityQ:IsFullyCastable() ) then
		return BOT_ACTION_DESIRE_NONE, 0
	end

	local nRadius = abilityQ:GetSpecialValueInt( 'radius_scepter' )
	local nCastRange = abilityQ:GetCastRange()
	local nCastPoint = abilityQ:GetCastPoint()
	local nManaCost = abilityQ:GetManaCost()
	local nSkillLV	 = abilityQ:GetLevel()
	
	
	---------------------------
	
	local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( nRadius, true, BOT_MODE_NONE )
	local nEnemyHeroes = bot:GetNearbyHeroes( 800, true, BOT_MODE_NONE )

	if J.IsRetreating( bot )
	then
		for _,npcEnemy in pairs( tableNearbyEnemyHeroes )
		do
			if nSkillLV >= 3 or nMP > 0.78 or J.GetHP(npcTarget) < 0.38 or nHP > 0.25
			then
			if J.CanCastOnNonMagicImmune( npcEnemy )
				and J.CanCastOnTargetAdvanced( npcEnemy )
				and ( bot:IsFacingLocation( npcEnemy:GetLocation(), 10 ) or #nEnemyHeroes <= 1 )
				and ( bot:WasRecentlyDamagedByHero( npcEnemy, 2.0 ) or nLV >= 10 )
			then
				return BOT_ACTION_DESIRE_HIGH, npcEnemy
			end
		end
	end
	end
	
	
	if ( bot:GetActiveMode() == BOT_MODE_ROSHAN )
	then
		local npcTarget = bot:GetAttackTarget()
		if ( J.IsRoshan( npcTarget ) and J.CanCastOnMagicImmune( npcTarget ) and J.IsInRange( npcTarget, bot, nCastRange ) )
		then
			return BOT_ACTION_DESIRE_LOW, npcTarget
		end
	end

	if J.IsInTeamFight( bot, 1400 ) 
	then
		if tableNearbyEnemyHeroes ~= nil
			and #tableNearbyEnemyHeroes >= 1
			and J.IsValidHero( tableNearbyEnemyHeroes[1] )
			and J.CanCastOnNonMagicImmune( tableNearbyEnemyHeroes[1] )
		then
			return BOT_ACTION_DESIRE_LOW, tableNearbyEnemyHeroes[1]
		end
	end

	if J.IsGoingOnSomeone( bot )
	then
		local npcTarget = J.GetProperTarget( bot )
		if J.IsValidHero( npcTarget )
			and J.CanCastOnNonMagicImmune( npcTarget )
			and J.IsInRange( npcTarget, bot, nRadius )
			and J.CanCastOnTargetAdvanced( npcTarget )
		then
			return BOT_ACTION_DESIRE_HIGH, npcTarget
		end

		if J.IsValid( npcTarget )
			and #hEnemyList == 0
			and J.IsAllowedToSpam( bot, nManaCost )
			and J.CanCastOnNonMagicImmune( npcTarget )
			and J.CanCastOnTargetAdvanced( npcTarget )
			and J.IsInRange( npcTarget, bot, nRadius )
			and not J.CanKillTarget( npcTarget, bot:GetAttackDamage() * 1.68, DAMAGE_TYPE_PHYSICAL )
		then
			local nCreeps = bot:GetNearbyCreeps( 800, true )
			if #nCreeps >= 1
			then
				return BOT_ACTION_DESIRE_HIGH, npcTarget
			end
		end

	end
	
	
	local hAlleyHeroList = bot:GetNearbyHeroes(1600, false, BOT_MODE_NONE);--1600范围内队友
	
	if #hAlleyHeroList >=1 then
		for _,ally in pairs( hAlleyHeroList )
		do
	
		if J.IsRetreating(ally)
		 then
			local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( 1200, true, BOT_MODE_NONE );
		for _,npcEnemy in pairs( tableNearbyEnemyHeroes )
		do
			if ( ally:WasRecentlyDamagedByHero( npcEnemy, 2.0 ) and J.CanCastOnNonMagicImmune(npcEnemy) and J.IsInRange(ally, bot, nCastRange)   ) 
			then
				return BOT_ACTION_DESIRE_MODERATE, ally;
			end
		end
	end
	end
	end
	

	return BOT_ACTION_DESIRE_NONE, 0

end


function X.ConsiderW()

	if not abilityW:IsFullyCastable() then
		return BOT_ACTION_DESIRE_NONE
	end
	
	
	local nAttackDamage = bot:GetAttackDamage();
	local nRadius = abilityW:GetSpecialValueInt( "landing_radius" )
	local nCastRange = abilityW:GetCastRange()
	local nCastPoint = abilityW:GetCastPoint()
	local nManaCost = abilityW:GetManaCost()
	local nSkillLV    = abilityW:GetLevel(); 
	local nBonus      = 24;
	local nDamage     = abilityW:GetSpecialValueInt( "impact_damage" );
	local nDamageType = DAMAGE_TYPE_MAGICAL;
	
	
	local nAllies =  bot:GetNearbyHeroes(1200,false,BOT_MODE_NONE);
	
	local nEnemysHerosInView  = bot:GetNearbyHeroes(1600,true,BOT_MODE_NONE);
	local nEnemysHerosInRange = bot:GetNearbyHeroes(nCastRange +50,true,BOT_MODE_NONE);
	local nEnemysHerosInBonus = bot:GetNearbyHeroes(nCastRange + 300,true,BOT_MODE_NONE);

	local nEnemysTowers   = bot:GetNearbyTowers(1400,true);
	local aliveEnemyCount = J.GetNumOfAliveHeroes(true);
	
	
	
	
	--击杀敌人
	for _,npcEnemy in pairs( nEnemysHerosInBonus )
	do
		if J.IsValid(npcEnemy)
		   and not npcEnemy:IsAttackImmune()
		   and J.CanCastOnMagicImmune(npcEnemy)
		   and GetUnitToUnitDistance(bot,npcEnemy) <= nCastRange + 80
		   and ( J.CanKillTarget(npcEnemy,nDamage *1.28,nDamageType)
				or ( npcEnemy:IsChanneling() and J.CanKillTarget(npcEnemy,nDamage *2.28,nDamageType)))
		then
			bot:SetTarget(npcEnemy);
			-- bot:ActionImmediate_Chat("For npcEnemy:IsChanneling() JUMP", true);
			return BOT_ACTION_DESIRE_HIGH, npcEnemy,npcEnemy:GetLocation();
			-- return BOT_ACTION_DESIRE_HIGH, npcEnemy;
		end
	end
	
	
	

	--撤退时逃跑
	if J.IsRetreating(bot) 
	    and bot:WasRecentlyDamagedByAnyHero(2.0)
	then
		local loc = J.GetEscapeLoc()
		local nAttackAllys = bot:GetNearbyHeroes(600,false,BOT_MODE_ATTACK);
		if #nAttackAllys == 0 or nHP < 0.13
		then
		    local nAllyInCastRange = bot:GetNearbyHeroes(nCastRange +80,false,BOT_MODE_NONE);
			local nAllyCreeps      = bot:GetNearbyCreeps(nCastRange +80,false);
			local nEnemyCreeps     = bot:GetNearbyCreeps(nCastRange +80,true);
			local nAllyUnits  = J.CombineTwoTable(nAllyInCastRange,nAllyCreeps)
			local nAllUnits   = J.CombineTwoTable(nAllyUnits,nEnemyCreeps)
			
			local targetUnit = nil
			local targetUnitDistance = J.GetDistanceFromAllyFountain(bot);
			for _,unit in pairs(nAllUnits)
			do
				if J.IsValid(unit)
					and GetUnitToUnitDistance(unit,bot) > 260
					and J.GetDistanceFromAllyFountain(unit) < targetUnitDistance
				then
					targetUnit = unit;
					targetUnitDistance = J.GetDistanceFromAllyFountain(unit)
				end
			end
			
			if targetUnit ~= nil
			then
				-- bot:ActionImmediate_Chat("J.IsRetreating(bot)  JUMP ", true);
				bot:SetTarget(targetUnit);
				return BOT_ACTION_DESIRE_HIGH, targetUnit,J.Site.GetXUnitsTowardsLocation(targetUnit, loc, nCastRange );
				-- return BOT_ACTION_DESIRE_HIGH, targetUnit;
				-- return BOT_ACTION_DESIRE_HIGH, J.Site.GetXUnitsTowardsUnits(targetUnit, loc, nCastRange );
			end
		end
	end

	--发育时对野怪输出
	if  J.IsFarming(bot) 
		and #hEnemyList == 0
		and not bot:HasModifier("modifier_filler_heal")
		and (bot:GetAttackTarget() == nil or not bot:GetAttackTarget():IsBuilding())
		and nLV >= 6
	then
		local nCreeps = bot:GetNearbyCreeps(nCastRange +80);
		
		-- local targetCreep = J.GetProperTarget(bot);--J.GetMostHpUnit(nCreeps);
		local targetCreep = J.GetMostHpUnit(nCreeps);
--		if nLV <= 14 then targetCreep = J.GetLeastHpUnit(nCreeps); end
		
		if J.IsValid(targetCreep)
			and not J.IsRoshan(targetCreep)
			and  ( not J.CanKillTarget(targetCreep,nDamage *2,nDamageType)
				   or GetUnitToUnitDistance(targetCreep,bot) >= 650 )
		then
			
			if J.IsAllowedToSpam(bot, nManaCost )			  
			then
				if ( #nCreeps >= 3 and GetUnitToUnitDistance(targetCreep,bot) <= 400 )
					or ( #nCreeps >= 2 and not J.CanKillTarget(targetCreep,nDamage *3,nDamageType))
					or ( #nCreeps >= 1 and not J.CanKillTarget(targetCreep,nDamage *6,nDamageType))
				then
					-- bot:ActionImmediate_Chat("J.IsFarming(bot)   JUMP ", true);
					-- return BOT_ACTION_DESIRE_HIGH, targetCreep;
					-- return BOT_ACTION_DESIRE_HIGH, targetCreep,targetCreep:GetLocation();
					return BOT_ACTION_DESIRE_HIGH, targetCreep
				end
			end
			
			if bot:GetMana() >= 100
				and GetUnitToUnitDistance(targetCreep,bot) >= 550
			then
				-- bot:ActionImmediate_Chat("J.IsFarming(bot)   JUMP ", true);
				bot:SetTarget(targetUnit);
				-- return BOT_ACTION_DESIRE_HIGH, targetCreep;
				
				return BOT_ACTION_DESIRE_HIGH, targetCreep,targetCreep:GetLocation();
			end
			
	    end
		
	end
	
	
	
	
	
	--推进时对小兵用
	if  (J.IsPushing(bot) or J.IsDefending(bot) or J.IsFarming(bot))
		and nLV >= 8
		and #nEnemysHerosInView == 0
		and #nAllies <= 2
	then
		local nLaneCreeps = bot:GetNearbyLaneCreeps(nCastRange +160,true);
		if  ( #nLaneCreeps >= 3 and J.IsAllowedToSpam(bot, nManaCost))
			or ( J.IsValid(nLaneCreeps[1]) 
				 and GetUnitToUnitDistance(nLaneCreeps[1],bot) >= 650
				 and bot:GetMana() >= 100 )
		then
			if J.IsValid(nLaneCreeps[1])
				and not J.IsEnemyHeroAroundLocation(nLaneCreeps[1]:GetLocation(), 1000)
			then
				for _,creep in pairs(nLaneCreeps)
				do
					if J.IsValid(creep)
						and not creep:HasModifier("modifier_fountain_glyph")
					then
						-- bot:ActionImmediate_Chat("(J.IsPushing(bot) or J.IsDefending(bot) or J.IsFarming(bot))   JUMP ", true);
						-- return BOT_ACTION_DESIRE_HIGH, creep;
						
						return BOT_ACTION_DESIRE_HIGH, creep,creep:GetLocation();
						-- return BOT_ACTION_DESIRE_HIGH, J.Site.GetXUnitsTowardsUnits(creep, bot:GetLocation(), RandomInt( 1, 200 ) );
					end
				end
			end
		end
	end
	
	--打肉的时候输出
	if  bot:GetActiveMode() == BOT_MODE_ROSHAN 
	then
		local npcTarget = bot:GetAttackTarget();
		if  J.IsRoshan(npcTarget) 
		    and J.GetHP(npcTarget) > 0.15
			and J.IsInRange(npcTarget, bot, nCastRange)  
		then
			-- bot:ActionImmediate_Chat("BOT_MODE_ROSHAN    JUMP ", true);
			return BOT_ACTION_DESIRE_HIGH, npcTarget,npcTarget:GetLocation();
			-- return BOT_ACTION_DESIRE_HIGH, npcTarget;
		end
	end
	
	
	
	--打架时先手	
	if J.IsGoingOnSomeone(bot)  
	   and ( #nAllies >= 2 or #nEnemysHerosInView <= 1 )
	then
	    local npcTarget = J.GetProperTarget(bot);
		if J.IsValidHero(npcTarget) 
			and not npcTarget:IsAttackImmune()
			and J.CanCastOnMagicImmune(npcTarget) 
			and J.IsInRange(npcTarget, bot, nCastRange/2) 
		then
			local tableNearbyEnemyHeroes = npcTarget:GetNearbyHeroes( 800, false, BOT_MODE_NONE );
			local tableNearbyAllyHeroes = npcTarget:GetNearbyHeroes( 800, true, BOT_MODE_NONE );
			local tableAllEnemyHeroes    = npcTarget:GetNearbyHeroes( 1600, false, BOT_MODE_NONE );
			if  ( J.WillKillTarget(npcTarget,nAttackDamage * 3,DAMAGE_TYPE_PHYSICAL,1.0) )
				or ( #tableNearbyEnemyHeroes <= #tableNearbyAllyHeroes )
				or ( #tableAllEnemyHeroes <= 1 )
				or GetUnitToUnitDistance(bot,npcTarget) <= 400
				or aliveEnemyCount <= 2 
			then 
				-- bot:ActionImmediate_Chat("J.IsGoingOnSomeone(bot)   JUMP ", true);
				-- return BOT_ACTION_DESIRE_HIGH,npcTarget
				return BOT_ACTION_DESIRE_HIGH,npcTarget,npcTarget:GetLocation();
				-- - RandomVector( 200 )
				-- return BOT_ACTION_DESIRE_HIGH, J.Site.GetXUnitsTowardsUnits(npcTarget, npcTarget:GetLocation(), RandomInt( 1, 200 ) );
			end
		end
	end
	
	
	
	if J.IsInTeamFight(bot, 1200) then
		local allies = bot:GetNearbyHeroes(nCastRange, false, BOT_MODE_NONE);
		local target = nil;
		local maxOP = 0;
		local allies = bot:GetNearbyHeroes(nCastRange, false, BOT_MODE_NONE);
		if #allies > 0 then
			for i=1,#allies do
				if J.CanCastOnNonMagicImmune(allies[i])
				   and allies[i]:GetAttackTarget() ~= nil	
				   and allies[i]:GetRawOffensivePower() >= maxOP
				then
					target = allies[i];
					maxOP = allies[i]:GetRawOffensivePower();
				end
			end
		end
		if target == nil then
			local minHP = 100000;
			if #allies > 0 then
				for i=1,#allies do
					if J.CanCastOnNonMagicImmune(allies[i])
					   and J.IsDisabled(allies[i])	
					   and allies[i]:GetHealth() <= minHP
					then
						target = allies[i];
						minHP = allies[i]:GetHealth();
					end
				end
			end
		end
		if target ~= nil then
			-- bot:ActionImmediate_Chat("J.IsInTeamFight(bot, 1200)   JUMP ", true);
			-- return BOT_ACTION_DESIRE_HIGH, target 
			return BOT_ACTION_DESIRE_HIGH, target,target:GetLocation();
			-- - RandomVector( 200 );
			
			-- return BOT_ACTION_DESIRE_HIGH,J.Site.GetXUnitsTowardsUnits(target, target:GetLocation(), RandomInt( 1, 200 ) );
		end
	end
	
	
	
	
	
	
	
	
	
	

	return BOT_ACTION_DESIRE_NONE

end

function X.ConsiderE()

	if not abilityE:IsTrained()
		or not abilityE:IsFullyCastable() 
	then
		return BOT_ACTION_DESIRE_NONE, 0
	end

	local nRadius = 700
	local nCastRange = abilityE:GetCastRange()
	local nCastPoint = abilityE:GetCastPoint()
	local nManaCost = abilityE:GetManaCost()

	--撤退时逃跑
	if J.IsRetreating(bot) 
	    and bot:WasRecentlyDamagedByAnyHero(2.0)
	then
		local nAttackAllys = bot:GetNearbyHeroes(1200,false,BOT_MODE_ATTACK);
		local nAttackEnemys = bot:GetNearbyHeroes( 1000, true, BOT_MODE_NONE );
		local target = nil;
		local maxOP = 0;
		if #nAttackAllys >= #nAttackEnemys or nHP < 0.13
		then
		   for i=1,#nAttackAllys do
		   if J.CanCastOnNonMagicImmune(nAttackAllys[i])
				   and nAttackAllys[i]:GetAttackTarget() ~= nil	
				   and nAttackAllys[i]:GetRawOffensivePower() >= maxOP
				then
					target = nAttackAllys[i];
					maxOP = nAttackAllys[i]:GetRawOffensivePower();
				end
			end
		end
		if target == nil then
		local minHP = 100000;
		
			if #nAttackAllys > 0 then
				for i=1,#nAttackAllys do
					if J.CanCastOnNonMagicImmune(nAttackAllys[i])
					   -- and J.IsDisabled(allies[i])	
					   and nAttackAllys[i]:GetHealth() <= minHP
					then
						target = nAttackAllys[i];
						minHP = nAttackAllys[i]:GetHealth();
					end
				end
			end
		end
	if target ~= nil then
			return BOT_ACTION_DESIRE_HIGH, target;
		end
	end	
	
	
	if bot:HasModifier("modifier_marci_unleash") then 
		return BOT_ACTION_DESIRE_VERIHIGH, bot;
	end
	 
	
	

	if J.IsInTeamFight(bot, 1200) then
		local allies = bot:GetNearbyHeroes(nCastRange, false, BOT_MODE_NONE);
		local target = nil;
		local maxOP = 0;
		local allies = bot:GetNearbyHeroes(nCastRange, false, BOT_MODE_NONE);
		if #allies > 0 then
			for i=1,#allies do
				if J.CanCastOnNonMagicImmune(allies[i])
				   and allies[i]:GetAttackTarget() ~= nil	
				   and allies[i]:GetRawOffensivePower() >= maxOP
				then
					target = allies[i];
					maxOP = allies[i]:GetRawOffensivePower();
				end
			end
		end
		if target == nil then
			local minHP = 100000;
			local maxAS = 0
			-- local maxAD = 0
			if #allies > 0 then
				for i=1,#allies do
					if J.CanCastOnNonMagicImmune(allies[i])	
					   and allies[i]:GetHealth() <= minHP
					   and allies[i]:GetAttackSpeed() > maxAS
					    -- and allies[i]:GetAttackDamage() > maxAD
					then
						target = allies[i];
						minHP = allies[i]:GetHealth();
					end
				end
			end
		end
		if target ~= nil and target:GetAttackTarget() ~= nil then
			return BOT_ACTION_DESIRE_HIGH, target;
		end
	end
	

	if J.IsGoingOnSomeone( bot )
	then
		local targetHero = J.GetProperTarget( bot )
		if J.IsValidHero( targetHero )
			and J.IsInRange( bot, targetHero, nCastRange )
			and J.CanCastOnNonMagicImmune( targetHero )
		then
			local cpos = utils.GetTowardsFountainLocation(targetHero:GetLocation(), 0);
				bot:ActionImmediate_Ping( cpos.x,  cpos.y, true)
			return BOT_ACTION_DESIRE_HIGH, bot
		end
	end
	
	
	
	
	-- If there is any ally seriously retreating, see if we can land a stun on someone who's damaged our ally recently
	
	local hAlleyHeroList = bot:GetNearbyHeroes(1600, false, BOT_MODE_NONE);--1600范围内队友
	
	if #hAlleyHeroList >=1 then
		for _,ally in pairs( hAlleyHeroList )
		do
	
		if J.IsRetreating(ally)
		 then
			local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( 1200, true, BOT_MODE_NONE );
		for _,npcEnemy in pairs( tableNearbyEnemyHeroes )
		do
			if ( ally:WasRecentlyDamagedByHero( npcEnemy, 2.0 ) and J.CanCastOnNonMagicImmune(npcEnemy) and J.IsInRange(ally, bot, nCastRange)   ) 
			then
				return BOT_ACTION_DESIRE_MODERATE, ally;
			end
		end
	end
	end
	end
	
	
	
	if DotaTime() >= lastCheck + 2.0 then 
		local weakest = nil;
		local minHP = 100000;
		local allies = bot:GetNearbyHeroes(nCastRange, false, BOT_MODE_NONE);
		if #allies > 0 then
			for i=1,#allies do
				if J.CanCastOnNonMagicImmune(allies[i])
				   and allies[i]:WasRecentlyDamagedByAnyHero(2.0) and allies[i]:GetAttackTarget() ~= nil
				   and allies[i]:GetHealth() <= minHP
     			   and allies[i]:GetHealth() <= 0.55*allies[i]:GetMaxHealth() 
				then
					weakest = allies[i];
					minHP = allies[i]:GetHealth();
				end
			end
		end
		if weakest ~= nil then
			return BOT_ACTION_DESIRE_HIGH, weakest;
		end
		lastCheck = DotaTime();
	end
	

	return BOT_ACTION_DESIRE_NONE, 0

end





function X.ConsiderR()
	-- 确保技能可以使用
    if not abilityR:IsTrained()
		or not abilityR:IsFullyCastable() 
	then
		return BOT_ACTION_DESIRE_NONE, 0
	end

    local nCastRange = bot:GetAttackRange();
	local nRadius = abilityR:GetSpecialValueInt("pulse_radius") - 100
	local nCastPoint = abilityR:GetCastPoint()
	
	local nAllys = bot:GetNearbyHeroes( 1200, false, BOT_MODE_NONE );
	local nEenemys = bot:GetNearbyHeroes(nRadius,true,BOT_MODE_NONE)
	local WeakestEnemy = J.GetVulnerableWeakestUnit(bot, true, true, nRadius + 300);
	local WeakestCreep = J.GetVulnerableWeakestUnit(bot, false, true, nRadius + 300);
	local nCreeps = bot:GetNearbyCreeps(nRadius,true)

	if nEenemys == nil then nEenemys = {} end
	if nCreeps == nil then nCreeps = {} end
	local count = #nEenemys+#nCreeps
	local nDamage = abilityR:GetSpecialValueInt("pulse_damage")*abilityR:GetSpecialValueInt("charges_per_flurry")/abilityR:GetSpecialValueFloat("time_between_flurries")
	
	
	-- If we're going after someone
    if bot:GetActiveMode() == BOT_MODE_ROAM
       or bot:GetActiveMode() == BOT_MODE_TEAM_ROAM
       or bot:GetActiveMode() == BOT_MODE_DEFEND_ALLY
       or bot:GetActiveMode() == BOT_MODE_ATTACK
	then
		local i = J.Item.AnyBlink()
		if i >= 0 and i <= 5
		then
			blink = bot:GetItemInSlot(i)
			i=nil
		end
	
		if blink~=nil and blink:IsFullyCastable()
		then
			local CastRange=1200
			local locationAoE = bot:FindAoELocation( true, true, bot:GetLocation(), CastRange, nRadius, 0, 0 );
			local locationAoE2 = bot:FindAoELocation( true, false, bot:GetLocation(), CastRange, nRadius, 0, 0 );
			if locationAoE.count+locationAoE2.count >= 6
			then
				bot:Action_UseAbilityOnLocation(blink, locationAoE.targetloc);
				return 0
			end
			
			if WeakestEnemy~=nil
			then
				if J.CanCastOnNonMagicImmune(WeakestEnemy)
				then
                    if WeakestEnemy:GetHealth() <= WeakestEnemy:GetActualIncomingDamage(nDamage, DAMAGE_TYPE_MAGICAL)
					then
						bot:Action_UseAbilityOnLocation(blink, WeakestEnemy:GetLocation());
						return 0
					end
				end
			end
		end
	end
	--------------------------------------
	-- Global high-priorty usage
	--------------------------------------
	--try to kill enemy hero
	if bot:GetActiveMode() ~= BOT_MODE_RETREAT and bot:HasModifier("modifier_marci_guardian_buff")
	then
		if WeakestEnemy~=nil 
		then
			if J.CanCastOnNonMagicImmune(WeakestEnemy)
			then
				if WeakestEnemy:GetHealth() <= WeakestEnemy:GetActualIncomingDamage(nDamage, DAMAGE_TYPE_MAGICAL)
				then
					return BOT_ACTION_DESIRE_MODERATE
				end
			end
		end
	end
	
	--------------------------------------
	-- Mode based usage
	--------------------------------------
	-- If we're going after someone
    if bot:GetActiveMode() == BOT_MODE_ROAM
       or bot:GetActiveMode() == BOT_MODE_TEAM_ROAM
       or bot:GetActiveMode() == BOT_MODE_DEFEND_ALLY
       or bot:GetActiveMode() == BOT_MODE_ATTACK
	then
		local npcEnemy = bot:GetTarget();

		if npcEnemy ~= nil and #nEenemys >= 2
		then
            if J.CanCastOnNonMagicImmune( npcEnemy ) 
               and GetUnitToUnitDistance(bot,npcEnemy) <= nRadius 
			then
				return BOT_ACTION_DESIRE_HIGH
			end
		end
	end

	if J.IsGoingOnSomeone(bot)
    then
        local npcTarget = J.GetProperTarget(bot);
        if J.IsValidHero(npcTarget) 
        and J.CanCastOnMagicImmune(npcTarget) 
        and J.IsInRange(npcTarget, bot, nCastRange + 200) 
        then
            if count >= 6 or mutil.IsDisabled2(npcTarget) then
                return BOT_ACTION_DESIRE_HIGH;
            end	
        end
	end
	
	if J.IsInTeamFight(bot, 1200)
	   and count >= 8 or bot:HasModifier("modifier_marci_guardian_buff") 
	
	then
        return BOT_ACTION_DESIRE_HIGH;
    end	

    return BOT_ACTION_DESIRE_NONE;
    
end





return X
-- dota2jmz@163.com QQ:2462331592.
