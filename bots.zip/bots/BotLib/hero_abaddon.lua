local X = {}
local bot = GetBot() --获取当前电脑

local J = require( GetScriptDirectory()..'/FunLib/jmz_func') --引入jmz_func文件
local ConversionMode = dofile( GetScriptDirectory()..'/AuxiliaryScript/BotlibConversion') --引入技能文件
local Minion = dofile( GetScriptDirectory()..'/FunLib/Minion') --引入Minion文件
local sTalentList = J.Skill.GetTalentList(bot) --获取当前英雄（当前电脑选择的英雄，一下省略为当前英雄）的天赋列表
local sAbilityList = J.Skill.GetAbilityList(bot) --获取当前英雄的技能列表
--编组技能、天赋、装备,以后独立出来，这个文件尽量小一些，增加可读性
local tGroupedDataList = {
	{
		--组合说明，不影响游戏
		['info'] = '主Q加点',
		--天赋树
		['Talent'] = {
			['t25'] = {10, 0},
			['t20'] = {0, 10},
			['t15'] = {10, 0},
			['t10'] = {0, 10},
		},
		--技能
		['Ability'] = {2,3,1,1,1,6,1,2,2,2,6,3,3,3,6},
		--装备
		['Buy'] = {
			'树之祭祀', -- 'item_tango',
			'两个魔法芒果', -- 'item_double_enchanted_mango'
			'压制之刃', -- 'item_quelling_blade',
			'魔法芒果', -- 'item_enchanted_mango',
			'魔杖', -- 'item_magic_wand',
			'护腕', -- 'item_bracer',
			'相位鞋', -- 'item_phase_boots',
			'刃甲', -- 'item_blade_mail',
			'弗拉迪米尔的祭品', -- 'item_vladmir',
			'回音战刃', -- 'item_echo_sabre',
			'辉耀', -- 'item_radiance',
			'阿哈利姆魔晶', -- 'item_aghanims_shard',
			'强袭胸甲', -- 'item_assault',
			'炎阳纹章', -- 'item_solar_crest',
			"阿哈利姆神杖", -- 'item_ultimate_scepter',
			'阿哈利姆神杖2', -- 'item_ultimate_scepter_2',
		},
		--出售
		['Sell'] = {
			'深渊之刃', -- 'item_abyssal_blade',
			'压制之刃', --'item_quelling_blade',
		},
	},
	{
		--组合说明，不影响游戏
		['info'] = '主被动加点',
		--天赋树
		['Talent'] = {
			['t25'] = {0, 10},
			['t20'] = {0, 10},
			['t15'] = {0, 10},
			['t10'] = {10, 0},
		},
		--技能
		['Ability'] = {2,3,2,3,2,6,1,3,2,3,1,1,1,6,6},
		--装备
		['Buy'] = {
			'树之祭祀', -- 'item_tango',
			'两个魔法芒果', -- 'item_double_enchanted_mango'
			'魔法芒果', -- 'item_enchanted_mango',
			'压制之刃', -- 'item_quelling_blade',
			'魔杖', -- 'item_magic_wand',
			'护腕', -- 'item_bracer',
			'相位鞋', -- 'item_phase_boots',
			'猎鹰战刃', -- 'item_falcon_blade',
			'刃甲', -- 'item_blade_mail',
			'回音战刃',  -- 'item_echo_sabre',
			'闪烁匕首', -- 'item_blink',
			'辉耀', -- 'item_radiance',
			'希瓦的守护', -- 'item_shivas_guard',
			'深渊之刃',  -- 'item_abyssal_blade',
			'阿哈利姆魔晶', -- 'item_aghanims_shard',
			'恐鳌之心', -- -- 'item_heart',
		},
		--出售
		['Sell'] = {
			'雷神之锤', -- 'item_mjollnir',
			'压制之刃', -- 'item_quelling_blade',

			'盛势闪光',
			'闪烁匕首', --'item_blink',
		},
	},
	{
		--组合说明，不影响游戏
		['info'] = 'By Misunderstand',
		--天赋树
		['Talent'] = {
			['t25'] = {0, 10},
			['t20'] = {10, 0},
			['t15'] = {10, 0},
			['t10'] = {0, 10},
		},
		--技能
		['Ability'] = { 1, 2, 1, 2, 1, 6, 3, 1, 2, 2, 6, 3, 3, 3, 6},
		--装备
		['Buy'] = {
			"树之祭祀", -- 'item_tango',
			"治疗药膏", -- 'item_flask',
			"魔法芒果", -- 'item_enchanted_mango',
			"压制之刃", -- 'item_quelling_blade',
			"魔棒", -- 'item_magic_stick',
			"魔杖", -- 'item_magic_wand',
			"相位鞋", -- 'item_phase_boots',
			"两个魔法芒果", -- 'item_double_enchanted_mango'
			"韧鼓", -- 'item_ancient_janggo',
			"勇气勋章", -- 'item_medallion_of_courage',
			"弗拉迪米尔的祭品", -- 'item_vladmir',
			"辉耀", -- 'item_radiance',
			"魂之灵瓮", -- 'item_spirit_vessel',
			"炎阳纹章", -- 'item_solar_crest',
			"阿哈利姆神杖", -- 'item_ultimate_scepter',
			"阿哈利姆神杖2", -- 'item_ultimate_scepter_2',
			"幻影斧", -- 'item_manta',
			"天堂之戟", -- 'item_heavens_halberd',
			"远行鞋2", -- 'item_travel_boots_2',
			"银月之晶", -- 'item_moon_shard',
		},
		--出售
		['Sell'] = {
			"韧鼓", -- 'item_ancient_janggo',
			"压制之刃", -- 'item_quelling_blade',
			
			"辉耀", -- 'item_radiance',
			"魔杖", -- 'item_magic_wand',

			"幻影斧", --'item_manta',
			"韧鼓", -- 'item_ancient_janggo',
			
			"天堂之戟", -- 'item_heavens_halberd',
			"弗拉迪米尔的祭品", -- 'item_vladmir',
			
			"远行鞋", -- 'item_travel_boots',
			"相位鞋", -- 'item_phase_boots',
		},
	},
}
--默认数据
local tDefaultGroupedData = {
	['Talent'] = {
		['t25'] = {10, 0},
		['t20'] = {10, 0},
		['t15'] = {10, 0},
		['t10'] = {10, 0},
	},
	['Ability'] = {2,1,1,3,1,6,1,2,2,2,6,3,3,3,6},
	['Buy'] = {
		'树之祭祀', -- 'item_tango',
		'治疗药膏', --'item_flask',
		'压制之刃', -- 'item_quelling_blade',
		'灵魂之戒', -- 'item_soul_ring',
		'相位鞋', -- 'item_phase_boots',
		'刃甲', -- 'item_blade_mail',
		'雷神之锤', -- 'item_mjollnir',
		'散夜对剑', -- 'item_sange_and_yasha',
		'辉耀', -- 'item_radiance',
		'撒旦之邪力', -- 'item_satanic',
		'恐鳌之心', -- 'item_heart',
	},
	['Sell'] = {
		'赤红甲', -- 'item_crimson_guard',
		'压制之刃', -- 'item_quelling_blade',
	}
}

--根据组数据生成技能、天赋、装备
local nAbilityBuildList, nTalentBuildList;

nAbilityBuildList, nTalentBuildList, X['sBuyList'], X['sSellList'] = ConversionMode.Combination(tGroupedDataList, tDefaultGroupedData, true)


nAbilityBuildList,nTalentBuildList,X['sBuyList'],X['sSellList'] = J.SetUserHeroInit(nAbilityBuildList,nTalentBuildList,X['sBuyList'],X['sSellList']);

X['sSkillList'] = J.Skill.GetSkillList(sAbilityList, nAbilityBuildList, sTalentList, nTalentBuildList)

X['bDeafaultAbility'] = true
X['bDeafaultItem'] = true

function X.MinionThink(hMinionUnit)

	if Minion.IsValidUnit(hMinionUnit) 
	then
		if hMinionUnit:IsIllusion() 
		then 
			Minion.IllusionThink(hMinionUnit)	
		end
	end

end

function X.SkillsComplement()

	--如果当前英雄无法使用技能或英雄处于隐形状态，则不做操作。
	if J.CanNotUseAbility(bot) or bot:IsInvisible() then return end
	--技能检查顺序
	local order = {'Q','W'}
	--委托技能处理函数接管
	if ConversionMode.Skills(order) then return; end

end

return X;