local X = {}
local bot = GetBot()

local J = require( GetScriptDirectory()..'/FunLib/jmz_func')
local ConversionMode = dofile( GetScriptDirectory()..'/AuxiliaryScript/BotlibConversion') --引入技能文件
local Minion = dofile( GetScriptDirectory()..'/FunLib/Minion')
local sTalentList = J.Skill.GetTalentList(bot)
local sAbilityList = J.Skill.GetAbilityList(bot)
local illuOrbLoc = nil

local tGroupedDataList = {
	
}
--默认数据
local tDefaultGroupedData = {
	['Talent'] = {
		['t25'] = {0, 10},
		['t20'] = {10, 0},
		['t15'] = {0, 10},
		['t10'] = {0, 10},
	},
	['Ability'] = {3,2,1,2,3,6,3,3,2,2,6,1,1,1,6},
	['Buy'] = {
		"树之祭祀", -- 'item_tango',
		"魔法芒果", -- 'item_enchanted_mango',
		"两个铁树枝干", -- 'item_double_branches',
		"净化药水", -- 'item_clarity',
		"静谧之鞋", -- 'item_tranquil_boots',
		"魔杖" , -- 'item_magic_wand',
		"韧鼓", -- 'item_ancient_janggo',
		"影之灵龛", -- 'item_urn_of_shadows',
		"阿托斯之棍", -- 'item_rod_of_atos',
		"微光披风", -- 'item_glimmer_cape',
		"原力法杖", -- 'item_force_staff',
		
		"阿哈利姆神杖", -- 'item_ultimate_scepter',
		"邪恶镰刀", -- 'item_sheepstick',
		"阿哈利姆神杖2", -- 'item_ultimate_scepter_2',
		-- "清莲宝珠", -- 'item_lotus_orb',
		'金箍棒', -- 'item_monkey_king_bar',
	},
	['Sell'] = {
		"魂之灵瓮",  -- 'item_spirit_vessel',
		"影之灵龛", -- 'item_urn_of_shadows',
		"韧鼓", -- 'item_ancient_janggo',
		"飓风长戟", -- 'item_hurricane_pike',
		"原力法杖", -- 'item_force_staff',
	}
}

local nAbilityBuildList, nTalentBuildList;

nAbilityBuildList, nTalentBuildList, X['sBuyList'], X['sSellList'] = ConversionMode.Combination(tGroupedDataList, tDefaultGroupedData, true)

nAbilityBuildList,nTalentBuildList,X['sBuyList'],X['sSellList'] = J.SetUserHeroInit(nAbilityBuildList,nTalentBuildList,X['sBuyList'],X['sSellList']);

X['sSkillList'] = J.Skill.GetSkillList(sAbilityList, nAbilityBuildList, sTalentList, nTalentBuildList)


X['bDeafaultAbility'] = true
X['bDeafaultItem'] = true

function X.MinionThink(hMinionUnit)

	if Minion.IsValidUnit(hMinionUnit) 
	then
		Minion.IllusionThink(hMinionUnit)
	end

end

function X.SkillsComplement()

	--如果当前英雄无法使用技能或英雄处于隐形状态，则不做操作。
	if J.CanNotUseAbility(bot) or bot:IsInvisible() then return end
	--技能检查顺序
	local order = {'Q','W','E','R','D'}
	--委托技能处理函数接管
	if ConversionMode.Skills(order) then return; end

end

return X
-- dota2jmz@163.com QQ:2462331592
