local X = {}
local bot = GetBot()

local J = require( GetScriptDirectory()..'/FunLib/jmz_func')
local ConversionMode = dofile( GetScriptDirectory()..'/AuxiliaryScript/BotlibConversion') --引入技能文件
local Minion = dofile( GetScriptDirectory()..'/FunLib/Minion')
local sTalentList = J.Skill.GetTalentList(bot)
local sAbilityList = J.Skill.GetAbilityList(bot)

--编组技能、天赋、装备
local tGroupedDataList = {
	{
		--组合说明，不影响游戏
		['info'] = 'By Misunderstand',
		--天赋树
		['Talent'] = {
			['t25'] = {0, 10},
			['t20'] = {10, 0},
			['t15'] = {10, 0},
			['t10'] = {10, 0},
		},
		--技能
		['Ability'] = { 1, 3, 1, 3, 1, 6, 1, 3, 2, 3, 6, 2, 2, 2, 6 },
		--装备
		['Buy'] = {
			"力量手套", -- 'item_gauntlets',
			"两个魔法芒果", -- 'item_double_enchanted_mango',
			"两个魔法芒果", -- 'item_double_enchanted_mango',
			"两个铁树枝干", -- 'item_double_branches',
			"魔棒", -- 'item_magic_stick',
			"风灵之纹", -- 'item_wind_lace',
			"护腕", -- 'item_double_bracer',
			"治疗药膏", -- 'item_flask',
			"魔杖", -- 'item_magic_wand',
			"远行鞋", -- 'item_travel_boots',
			"回复戒指", -- 'item_ring_of_health',
			"净化药水", -- 'item_clarity',
			"闪烁匕首", -- 'item_blink',
			"原力法杖", -- 'item_force_staff',
			"黑皇杖", -- 'item_black_king_bar',
			"陨星锤", -- 'item_meteor_hammer',
			"林肯法球", -- 'item_sphere',
			"阿哈利姆神杖2", -- 'item_ultimate_scepter_2',
			"飓风长戟", -- 'item_hurricane_pike',
			"远行鞋2", -- 'item_travel_boots_2',
			"银月之晶" -- 'item_moon_shard',
		},
		--出售
		['Sell'] = {
			"原力法杖", -- 'item_force_staff',     
			"风灵之纹", -- 'item_wind_lace',

			"黑皇杖", -- 'item_black_king_bar',
			"护腕",  -- 'item_double_bracer',   

			"陨星锤",
			"魔杖" -- -- 'item_magic_wand',
		},
	},
	{
		--组合说明，不影响游戏
		['info'] = 'By 铅笔会有猫的w',
		['Talent'] = {
			['t25'] = {10, 0},
			['t20'] = {0, 10},
			['t15'] = {0, 10},
			['t10'] = {0, 10},
		},
		['Ability'] = { 1, 3, 3, 1, 3, 6, 2, 3, 1, 1, 6, 2, 2, 2, 6},
		['Buy'] = {
			"两个树之祭祀", --'item_double_tango',
			"治疗药膏", -- 'item_flask',
			"两个魔法芒果", -- 'item_double_enchanted_mango',
			"王冠", -- 'item_crown',
			"魔棒", -- 'item_magic_stick',
			"速度之靴", -- 'item_boots',
			"韧鼓",-- 'item_ancient_janggo',
			"闪烁匕首", -- 'item_blink',
			"原力法杖", -- 'item_force_staff',
			"以太透镜", -- 'item_aether_lens',
			"远行鞋", -- 'item_travel_boots',
			"黑皇杖", -- 'item_black_king_bar',
			"阿哈利姆神杖2", -- 'item_ultimate_scepter_2',
			"希瓦的守护", -- 'item_shivas_guard',
			"远行鞋2", -- 'item_travel_boots_2',
			"银月之晶" -- 'item_moon_shard',
		},
		['Sell'] = {
			"黑皇杖", -- 'item_black_king_bar',
			"魔棒", -- 'item_magic_stick',

			"希瓦的守护", -- 'item_shivas_guard',
			"韧鼓", -- 'item_ancient_janggo',
		}
	},
}
--默认数据
local tDefaultGroupedData = {
	--天赋树
	['Talent'] = {
		['t25'] = {10, 0},
		['t20'] = {10, 0},
		['t15'] = {10, 0},
		['t10'] = {10, 0},
	},
	--技能
	['Ability'] = {1,3,1,2,1,6,1,3,3,3,6,2,2,2,6},
	--装备
	['Buy'] = {
		"树之祭祀", -- 'item_tango',
		"治疗药膏", -- 'item_flask',
		"魔杖", -- 'item_magic_wand',
		"静谧之鞋", -- 'item_tranquil_boots',
		"闪烁匕首",  -- 'item_blink',
		"原力法杖", -- 'item_force_staff',
		"黑皇杖", -- 'item_black_king_bar',
		"Eul的神圣法杖", -- 'item_cyclone',
		"阿哈利姆神杖", -- 'item_ultimate_scepter',
		"飓风长戟", -- 'item_hurricane_pike',
		"玲珑心", -- 'item_octarine_core',
	},
	--出售
	['Sell'] = {
		"Eul的神圣法杖", -- 'item_cyclone',
		"魔杖", -- -- 'item_magic_wand',
	},
}

--根据组数据生成技能、天赋、装备
local nAbilityBuildList, nTalentBuildList;

nAbilityBuildList, nTalentBuildList, X['sBuyList'], X['sSellList'] = ConversionMode.Combination(tGroupedDataList, tDefaultGroupedData, true)

nAbilityBuildList,nTalentBuildList,X['sBuyList'],X['sSellList'] = J.SetUserHeroInit(nAbilityBuildList,nTalentBuildList,X['sBuyList'],X['sSellList']);

X['sSkillList'] = J.Skill.GetSkillList(sAbilityList, nAbilityBuildList, sTalentList, nTalentBuildList)

X['bDeafaultAbility'] = false
X['bDeafaultItem'] = true

function X.MinionThink(hMinionUnit)

	if Minion.IsValidUnit(hMinionUnit) 
	then
		Minion.IllusionThink(hMinionUnit)
	end

end

function X.SkillsComplement()
	
	--如果当前英雄无法使用技能或英雄处于隐形状态，则不做操作。
	if J.CanNotUseAbility(bot) or bot:IsInvisible() then return end
	--技能检查顺序
	local order = {'R','E','W','Q'}
	--委托技能处理函数接管
	if ConversionMode.Skills(order) then return; end

end

return X
