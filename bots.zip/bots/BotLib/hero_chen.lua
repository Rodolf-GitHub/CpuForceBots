local X = {}
local bot = GetBot()

local J = require( GetScriptDirectory()..'/FunLib/jmz_func')
local ConversionMode = dofile( GetScriptDirectory()..'/AuxiliaryScript/BotlibConversion') --引入技能文件
local Minion = dofile( GetScriptDirectory()..'/FunLib/Minion')
local sTalentList = J.Skill.GetTalentList(bot)
local sAbilityList = J.Skill.GetAbilityList(bot)

--编组技能、天赋、装备
local tGroupedDataList = {}
--默认数据
local tDefaultGroupedData = {
	['Talent'] = {
		['t25'] = {0, 10},
		['t20'] = {10, 0},
		['t15'] = {0, 10},
		['t10'] = {10, 0},
	},
	['Ability'] = {1,3,1,3,1,6,1,2,3,3,6,2,2,2,6},
	['Buy'] = {
		"树之祭祀", -- 'item_tango',
		-- "两个魔法芒果", -- 'item_double_enchanted_mango',
		"魔法芒果", -- 'item_enchanted_mango',
		'魔杖', -- 'item_magic_wand',
		'王者之戒',      --'item_ring_of_basilius'
		'速度之靴', -- 'item_boots',
		'护腕', -- 'item_bracer',
		-- "风灵之纹", -- 'item_wind_lace',
		-- "力量手套", -- 'item_gauntlets',
		'弗拉迪米尔的祭品', -- 'item_vladmir',
		"奥术鞋", -- 'item_arcane_boots',
		
		
		-- "勇气勋章", -- 'item_medallion_of_courage',
		-- "影之灵龛", -- 'item_urn_of_shadows',
		"阿托斯之棍", -- 'item_rod_of_atos',
		"梅肯斯姆", -- 'item_mekansm',
		'原力法杖', -- 'item_force_staff',
		'影刃', -- 'item_invis_sword',
		"阿哈利姆神杖", -- 'item_ultimate_scepter',
		'卫士胫甲', --'item_guardian_greaves',
		'阿哈利姆神杖2', -- 'item_ultimate_scepter_2',
		'飓风长戟', -- 'item_hurricane_pike',
		'统御头盔', -- 'item_helm_of_the_overlord',
		"邪恶镰刀", -- 'item_sheepstick',		
		'白银之锋', -- 'item_silver_edge',
		-- "死灵书3",
		
	},
	['Sell'] = {
		"洞察烟斗", -- 'item_pipe',
		"勇气勋章", -- 'item_medallion_of_courage',
	}
}

--根据组数据生成技能、天赋、装备
local nAbilityBuildList, nTalentBuildList;

nAbilityBuildList, nTalentBuildList, X['sBuyList'], X['sSellList'] = ConversionMode.Combination(tGroupedDataList, tDefaultGroupedData, true)

nAbilityBuildList,nTalentBuildList,X['sBuyList'],X['sSellList'] = J.SetUserHeroInit(nAbilityBuildList,nTalentBuildList,X['sBuyList'],X['sSellList']);

X['sSkillList'] = J.Skill.GetSkillList(sAbilityList, nAbilityBuildList, sTalentList, nTalentBuildList)

X['bDeafaultAbility'] = true
X['bDeafaultItem'] = true

function X.MinionThink(hMinionUnit)

	if Minion.IsValidUnit(hMinionUnit) 
	then
		if hMinionUnit:IsIllusion() 
		then 
			Minion.IllusionThink(hMinionUnit)	
		end
	end

end

local hEnemyOnceLocation = {}

for _,TeamPlayer in pairs( GetTeamPlayers(GetOpposingTeam()) )
do
    hEnemyOnceLocation[TeamPlayer] = nil;
end

local hEnemyRecordLocation = {}

function X.SkillsComplement()
	
	if J.CanNotUseAbility(bot) or bot:IsInvisible() then return end

	--如果当前英雄无法使用技能或英雄处于隐形状态，则不做操作。
	if J.CanNotUseAbility(bot) or bot:IsInvisible() then return end
	--技能检查顺序
	local order = {"Q",'R'}
	--委托技能处理函数接管
	if ConversionMode.Skills(order) then return; end

end

return X