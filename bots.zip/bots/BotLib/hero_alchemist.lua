----------------------------------------------------------------------------------------------------
--- The Creation Come From: BOT EXPERIMENT Credit:FURIOUSPUPPY
--- BOT EXPERIMENT Author: Arizona Fauzie 2018.11.21
--- Link:http://steamcommunity.com/sharedfiles/filedetails/?id=837040016
--- Refactor: 决明子 Email: dota2jmz@163.com 微博@Dota2_决明子
--- Link:http://steamcommunity.com/sharedfiles/filedetails/?id=1573671599
--- Link:http://steamcommunity.com/sharedfiles/filedetails/?id=1627071163
----------------------------------------------------------------------------------------------------
local X = {}
local bDebugMode = ( 1 == 10 )
local bot = GetBot()

local J = require( GetScriptDirectory()..'/FunLib/jmz_func') --引入jmz_func文件
-- local ConversionMode = dofile('bots/AuxiliaryScript/BotlibConversion') --引入技能文件
local Minion = dofile( GetScriptDirectory()..'/FunLib/Minion') --引入Minion文件
local utils = require(GetScriptDirectory().."/util")
local mutil = require( GetScriptDirectory().."/MyUtility")
local mutils = require( GetScriptDirectory().."/MyUtility")

local sTalentList = J.Skill.GetTalentList( bot )
local sAbilityList = J.Skill.GetAbilityList( bot )
local sOutfitType = J.Item.GetOutfitType( bot )

local tTalentTreeList = {
						['t25'] = {0, 10},
						['t20'] = {0, 10},
						['t15'] = {10, 0},
						['t10'] = {0, 10},
}

local tAllAbilityBuildList = {
						{1,3,2,1,2,6,1,1,2,2,6,3,3,3,6},
						{1,3,1,2,1,6,1,2,2,2,6,3,3,3,6},
}

local nAbilityBuildList = J.Skill.GetRandomBuild( tAllAbilityBuildList )

local nTalentBuildList = J.Skill.GetTalentBuild( tTalentTreeList )

local tOutFitList = {}

tOutFitList['outfit_carry'] = {

	"item_sven_outfit",
	--"item_bracer",
	"item_blade_mail",
	"item_echo_sabre",
	-- "item_aghanims_shard",
	"item_black_king_bar",
	-- "item_travel_boots",
	-- "item_greater_crit",
	"item_overwhelming_blink",
	"item_assault",
	-- "item_abyssal_blade",
--	"item_heart",
	"item_moon_shard",
	"item_travel_boots_2",
--	"item_ultimate_scepter_2",

}

tOutFitList['outfit_mid'] = tOutFitList['outfit_carry']

tOutFitList['outfit_priest'] = tOutFitList['outfit_carry']

tOutFitList['outfit_mage'] = tOutFitList['outfit_carry']

tOutFitList['outfit_tank'] = {

	"item_tank_outfit",
	"item_hood_of_defiance",
	"item_pipe",
	-- "item_vanguard",
	-- "item_crimson_guard",
	-- "item_aghanims_shard",
	-- "item_heavens_halberd",
--	"item_lotus_orb",
	"item_echo_sabre",
	"item_moon_shard",
	"item_assault",
	-- "item_travel_boots",
	-- "item_greater_crit",
	"item_heart",
	"item_shivas_guard",
	
	"item_travel_boots_2",
--	"item_ultimate_scepter_2",

}

X['sBuyList'] = tOutFitList[sOutfitType]

X['sSellList'] = {

	"item_travel_boots",
	"item_quelling_blade",

	-- "item_black_king_bar",
	"item_magic_wand",
	
	"item_travel_boots",
	"item_magic_wand",
	
	-- "item_assault",
	"item_ancient_janggo",

}


if J.Role.IsPvNMode() or J.Role.IsAllShadow() then X['sBuyList'], X['sSellList'] = { 'PvN_tank' }, {"item_power_treads", 'item_quelling_blade'} end

nAbilityBuildList, nTalentBuildList, X['sBuyList'], X['sSellList'] = J.SetUserHeroInit( nAbilityBuildList, nTalentBuildList, X['sBuyList'], X['sSellList'] )

X['sSkillList'] = J.Skill.GetSkillList( sAbilityList, nAbilityBuildList, sTalentList, nTalentBuildList )

X['bDeafaultAbility'] = false
X['bDeafaultItem'] = false

function X.MinionThink( hMinionUnit )

	if Minion.IsValidUnit( hMinionUnit )
	then
		Minion.IllusionThink( hMinionUnit )
	end

end

--[[

npc_dota_hero_alchemist

"Ability1"		"alchemist_acid_spray"
"Ability2"		"alchemist_unstable_concoction"
"Ability3"		"alchemist_goblins_greed"
"Ability4"		"alchemist_berserk_potion"
"Ability5"		"generic_hidden"
"Ability6"		"alchemist_chemical_rage"
"Ability7"		"alchemist_unstable_concoction_throw"
"Ability10"		"special_bonus_attack_speed_15"
"Ability11"		"special_bonus_unique_alchemist"
"Ability12"		"special_bonus_hp_350"
"Ability13"		"special_bonus_attack_damage_20"
"Ability14"		"special_bonus_cleave_25"
"Ability15"		"special_bonus_unique_alchemist_2"
"Ability16"		"special_bonus_unique_alchemist_6"
"Ability17"		"special_bonus_unique_alchemist_4"

modifier_item_ultimate_scepter_consumed_alchemist
modifier_alchemist_acid_spray_thinker
modifier_alchemist_acid_spray
modifier_alchemist_unstable_concoction
modifier_alchemist_goblins_greed
modifier_alchemist_chemical_rage_transform
modifier_alchemist_chemical_rage
modifier_alchemist_scepter_bonus_damage
modifier_alchemist_berserk_potion


--]]



local abilityQ = "";
local abilityW = "";
local abilityW2 = "";
local abilityR = "";
local abilityBP = "";



if abilityQ == "" then abilityQ = bot:GetAbilityByName( sAbilityList[1] ) end
if abilityW == "" then abilityW = bot:GetAbilityByName( sAbilityList[2] ) end
if abilityW2 == "" then abilityW2 = bot:GetAbilityByName( "alchemist_unstable_concoction_throw" ) end
if abilityR == "" then abilityR = bot:GetAbilityByName( sAbilityList[6] ) end
if abilityBP == "" then abilityBP = bot:GetAbilityByName( "alchemist_berserk_potion" ) end


local defDuration = 2;
local offDuration = 4.25;
CCStartTime = 0;


local castQDesire, castQTarget;
local castWDesire;
local castW2Desire, castW2Target;
local castRDesire;
local castDDesire, castDTarget;

local nKeepMana, nMP, nHP, nLV, hEnemyList, hAllyList, botTarget, sMotive;
local aetherRange = 0;


function X.SkillsComplement()

	if J.CanNotUseAbility( bot ) or bot:IsInvisible() then return end

	nKeepMana = 400
	aetherRange = 0
	nLV = bot:GetLevel()
	nMP = bot:GetMana() / bot:GetMaxMana()
	nHP = bot:GetHealth() / bot:GetMaxHealth()
	botTarget = J.GetProperTarget( bot )
	hEnemyList = bot:GetNearbyHeroes( 1600, true, BOT_MODE_NONE )
	hAllyList = J.GetAlliesNearLoc( bot:GetLocation(), 1600 )


	--计算天赋可能带来的通用变化
	local aether = J.IsItemAvailable( "item_aether_lens" )
	if aether ~= nil then aetherRange = 250 end
	
	
	
	
	castQDesire, castQTarget, sMotive = X.ConsiderQ()
	if castQDesire > 0
	then
		J.SetReportMotive( bDebugMode, sMotive );

		J.SetQueuePtToINT( bot, true );

		bot:ActionQueue_UseAbilityOnLocation( abilityQ, castQTarget );
		return
	end
	
	
	
	castWDesire = X.ConsiderW()
	if castWDesire > 0
	then
		
		-- J.SetQueuePtToINT( bot, true );
		bot:ActionQueue_UseAbility( abilityW  );
		CCStartTime =  DotaTime();
		
		return
	end
	
	
	castW2Desire,castW2Target  = X.ConsiderW2()
	if castW2Desire > 0 then
		-- J.SetQueuePtToINT( bot, true )
		bot:Action_ClearActions(false)
		bot:ActionQueue_UseAbilityOnEntity( abilityW2,castW2Target );
		return
	end

	
	castRDesire = X.ConsiderR()
	if castRDesire > 0
	then
		
		J.SetQueuePtToINT( bot, true );
		bot:ActionQueue_UseAbility( abilityR );
	end

	castBPDesire, castBPTarget = ConsiderBerserkPotion();
	if ( castBPDesire > 0 ) 
	then
		-- local typeAOE = mutil.CheckFlag(abilityBP:GetBehavior(), ABILITY_BEHAVIOR_UNIT_TARGET);
		-- if typeAOE == true then
		bot:ActionPush_UseAbilityOnEntity( abilityBP, castBPTarget );
		return;
	end
	


end


function X.ConsiderQ()


	if not abilityQ:IsFullyCastable() 
	then
	return BOT_ACTION_DESIRE_NONE
    end

	local nSkillLV = abilityQ:GetLevel()
	local nCastRange = abilityQ:GetCastRange()
	-- local nCastRange = J.GetProperCastRange(false, bot, abilityQ:GetCastRange());
	local nRadius = abilityQ:GetSpecialValueInt( 'radius' )
	local nCastPoint = abilityQ:GetCastPoint()
	local nManaCost = abilityQ:GetManaCost()
	local nDamage = abilityQ:GetSpecialValueInt('damage') * abilityQ:GetSpecialValueFloat('duration') / 2;
	local nDamageType = DAMAGE_TYPE_MAGICAL
	-- local nDamageType = DAMAGE_TYPE_PHYSICAL
	local nInRangeEnemyList = J.GetAroundEnemyHeroList( nRadius )
	local nInBonusEnemyList = J.GetAroundEnemyHeroList( nRadius + 200 )
	local hCastTarget = nil
	local sCastMotive = nil
	
	--击杀
	for _, npcEnemy in pairs( nInRangeEnemyList )
	do
		if J.IsValidHero( npcEnemy )
			and J.CanCastOnNonMagicImmune( npcEnemy )
			and J.WillMagicKillTarget( bot, npcEnemy, nDamage, nCastPoint )
		then
			hCastTarget = npcEnemy:GetLocation()
			return BOT_ACTION_DESIRE_HIGH, hCastTarget, 'Q-击杀'..J.Chat.GetNormName( npcEnemy )
		end
	end

	--消耗
	local nCanHurtEnemyAoE = bot:FindAoELocation( true, true, bot:GetLocation(), nRadius , nRadius , 0, 0 )
	if nCanHurtEnemyAoE.count >= 3
	then
		hCastTarget = nCanHurtEnemyAoE.targetloc
		return BOT_ACTION_DESIRE_HIGH, hCastTarget, 'Q-消耗'
	end


	--对线消耗或补刀
	if J.IsLaning( bot )
	then
		--对线消耗
		local nAoeLoc = J.GetAoeEnemyHeroLocation( bot, nRadius - 80, nRadius - 80, 2 )
		if nAoeLoc ~= nil and nMP > 0.38
		then
			hCastTarget = nAoeLoc
			return BOT_ACTION_DESIRE_HIGH, hCastTarget, 'Q-对线消耗'
		end
	end


	--团战
	if J.IsInTeamFight( bot, 1200 )
	then
		local nAoeLoc = J.GetAoeEnemyHeroLocation( bot, nCastRange, nRadius - 100, 2 )
		if nAoeLoc ~= nil
		then
			hCastTarget = nAoeLoc
			return BOT_ACTION_DESIRE_HIGH, hCastTarget, 'Q-团战'
		end
	end


	--打架时先手
	if J.IsGoingOnSomeone( bot )
	then
		if J.IsValidHero( botTarget )
			and J.CanCastOnNonMagicImmune( botTarget )
			and J.IsInRange( botTarget, bot,nRadius - 80 )
		then
			if nSkillLV >= 2 or nMP > 0.68 or J.GetHP( botTarget ) < 0.38
			then
				hCastTarget = J.GetCastLocation( bot, botTarget, nRadius - 80, nRadius - 80 )
				if hCastTarget ~= nil
				then
					return BOT_ACTION_DESIRE_HIGH, hCastTarget, 'Q-攻击'..J.Chat.GetNormName( botTarget )
				end
			end
		end
	end


	--撤退前加速
	if J.IsRetreating( bot ) 
		-- and not bot:HasModifier( 'modifier_legion_commander_overwhelming_odds' )
	then
		for _, npcEnemy in pairs( nInRangeEnemyList )
		do
			if J.IsValid( npcEnemy )
				and bot:WasRecentlyDamagedByHero( npcEnemy, 5.0 )
				and J.CanCastOnNonMagicImmune( npcEnemy )
				and J.IsInRange(bot,npcEnemy,nRadius)
				--and bot:IsFacingLocation( npcEnemy:GetLocation(), 40 )
			then
				hCastTarget = npcEnemy:GetLocation()
				return BOT_ACTION_DESIRE_HIGH, hCastTarget, 'Q-撤退'..J.Chat.GetNormName( npcEnemy )
			end
		end
	end


	--打钱
	if J.IsFarming( bot )
		and nSkillLV >= 3
		and J.IsAllowedToSpam( bot, nManaCost * 0.25 )
	then
		if J.IsValid( botTarget )
			and botTarget:GetTeam() == TEAM_NEUTRAL
			and J.IsInRange( bot, botTarget, 1000 )
			and ( botTarget:GetMagicResist() < 0.4 or nMP > 0.9 )
		then
			local nShouldHurtCount = nMP > 0.55 and 3 or 4
			local locationAoE = bot:FindAoELocation( true, false, bot:GetLocation(), nRadius - 80, nRadius - 50, 0, 0 )
			if ( locationAoE.count >= nShouldHurtCount )
			then
				hCastTarget = locationAoE.targetloc
				return BOT_ACTION_DESIRE_HIGH, hCastTarget, "Q-打钱"..locationAoE.count
			end
		end
	end


	--推进时对小兵用
	if ( J.IsPushing( bot ) or J.IsDefending( bot ) or J.IsFarming( bot ) )
		and J.IsAllowedToSpam( bot, nManaCost * 0.32 )
		and nSkillLV >= 2 and DotaTime() > 6 * 60
		and #hAllyList <= 3 and #hEnemyList == 0
	then
		local laneCreepList = bot:GetNearbyLaneCreeps( 1400, true )
		if #laneCreepList >= 4
			and J.IsValid( laneCreepList[1] )
			and not laneCreepList[1]:HasModifier( "modifier_fountain_glyph" )
		then

			local locationAoEHurt = bot:FindAoELocation( true, false, bot:GetLocation(), nCastRange - 300, nRadius - 50, 0, 0 )
			if locationAoEHurt.count >= 4 
			then
				hCastTarget = locationAoEHurt.targetloc
				return BOT_ACTION_DESIRE_HIGH, hCastTarget, "Q-带线"..locationAoEHurt.count
			end
		end
	end
	
	if ( bot:GetActiveMode() == BOT_MODE_ROSHAN  ) 
	then
		local npcTarget = bot:GetAttackTarget();
		if ( J.IsRoshan(npcTarget) and J.CanCastOnMagicImmune(npcTarget) and J.IsInRange(npcTarget, bot, nRadius)  )
		then
			hCastTarget = npcTarget:GetLocation()
			return BOT_ACTION_DESIRE_LOW, hCastTarget,'Q-团战';
		end
	end


	return BOT_ACTION_DESIRE_NONE


end



function X.ConsiderW()


	if not abilityW:IsFullyCastable() or abilityW:IsHidden()  
	then 
	return BOT_ACTION_DESIRE_NONE
	end

	
	local nCastRange = abilityW:GetCastRange()
	local nDamage = abilityW:GetSpecialValueInt( "max_damage" );
	local nDamageType = DAMAGE_TYPE_MAGICAL	
	
	
	
	
	
	--------------------------------------
	-- Mode based usage
	--------------------------------------

	-- If we're seriously retreating, see if we can land a stun on someone who's damaged us recently
	if J.IsRetreating(bot)
	then
		local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( nCastRange, true, BOT_MODE_NONE );
		for _,npcEnemy in pairs( tableNearbyEnemyHeroes )
		do
			if ( bot:WasRecentlyDamagedByHero( npcEnemy, 1.0 )  and J.CanCastOnNonMagicImmune(npcEnemy) ) 
			then
				return BOT_ACTION_DESIRE_MODERATE;
			end
		end
	end

	-- If a mode has set a target, and we can kill them, do it
	local npcTarget = bot:GetTarget();
	if ( J.IsValidHero(npcTarget) and J.CanCastOnNonMagicImmune(npcTarget) )
	then
		if (  J.CanKillTarget(npcTarget, nDamage, nDamageType) and J.IsInRange(npcTarget, bot, nCastRange - 200)  )
		then
			return BOT_ACTION_DESIRE_HIGH;
		end
	end
	
	-- If we're going after someone
	if J.IsGoingOnSomeone(bot)
	then
		if J.IsValidHero(npcTarget) and J.CanCastOnNonMagicImmune(npcTarget) and J.IsInRange(npcTarget, bot, nCastRange - 200)
		then
			return BOT_ACTION_DESIRE_HIGH;
		end
	end
	
	if ( bot:GetActiveMode() == BOT_MODE_ROSHAN  ) 
	then
		local npcTarget = bot:GetAttackTarget();
		if ( J.IsRoshan(npcTarget) and J.CanCastOnMagicImmune(npcTarget) and J.IsInRange(npcTarget, bot, nCastRange)  )
		then
			return BOT_ACTION_DESIRE_LOW;
		end
	end
	


	return BOT_ACTION_DESIRE_NONE


end





function X.ConsiderW2()

	
	
	-- Make sure it's castable
	if ( not abilityW2:IsFullyCastable() or abilityW2:IsHidden() ) then 
		return BOT_ACTION_DESIRE_NONE;
	end
	
	-- Get some of its values
	local nCastRange = abilityW2:GetCastRange();
	local nDamage = abilityW2:GetSpecialValueInt( "max_damage" );
	
	
	-- If a mode has set a target, and we can kill them, do it
	local npcTarget = bot:GetTarget();
	if ( mutil.IsValidTarget(npcTarget) and mutil.CanCastOnNonMagicImmune(npcTarget) )
	then
		if ( ( DotaTime() == CCStartTime + offDuration or 
				mutil.CanKillTarget(npcTarget, nDamage, DAMAGE_TYPE_PHYSICAL)  ) and 
				mutil.IsInRange(npcTarget, bot, nCastRange + 200) )
		then
			return BOT_ACTION_DESIRE_HIGH, npcTarget;
		end
	end
	
	
	-- If we're seriously retreating, see if we can land a stun on someone who's damaged us recently
	if mutil.IsRetreating(bot)
	then
		local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( nCastRange, true, BOT_MODE_NONE );
		for _,npcEnemy in pairs( tableNearbyEnemyHeroes )
		do 
			if ( bot:WasRecentlyDamagedByHero( npcEnemy, 2.0 ) and mutil.CanCastOnNonMagicImmune(npcEnemy) and DotaTime() >= CCStartTime + defDuration ) 
			then
				
				return BOT_ACTION_DESIRE_HIGH, npcEnemy;
			end
		end
	end

	-- If we're going after someone
	if mutil.IsGoingOnSomeone(bot)
	then
		if mutil.IsValidTarget(npcTarget) and 
		   mutil.CanCastOnNonMagicImmune(npcTarget) and 
		   ( DotaTime() >= CCStartTime + offDuration or npcTarget:GetHealth() < nDamage or npcTarget:IsChanneling() ) 
		then
			local cpos = utils.GetTowardsFountainLocation(npcTarget:GetLocation(), 0);
				bot:ActionImmediate_Ping( cpos.x,  cpos.y, true)
			return BOT_ACTION_DESIRE_MODERATE, npcTarget;
		end
	end

	local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( 1300, true, BOT_MODE_NONE );
	for _,npcEnemy in pairs( tableNearbyEnemyHeroes )
	do
		if ( mutil.CanCastOnNonMagicImmune(npcEnemy) and 
		   ( DotaTime() >= CCStartTime + offDuration or npcEnemy:GetHealth() < nDamage or npcEnemy:IsChanneling() ) and 
		   mutil.IsInRange(npcTarget, bot, nCastRange+200)  ) 
		then
			
			return BOT_ACTION_DESIRE_HIGH, npcEnemy;
		end
	end
	
	return BOT_ACTION_DESIRE_NONE;
    
end

function X.ConsiderR()


	-- Make sure it's castable
	if ( not abilityR:IsFullyCastable() ) then 
		return BOT_ACTION_DESIRE_NONE;
	end
	
	local nRadius = 1000;
	
	if bot:GetHealth() / bot:GetMaxHealth() < 0.5 then
		return BOT_ACTION_DESIRE_LOW;
	end
	
	-- If we're seriously retreating, see if we can land a stun on someone who's damaged us recently
	if mutil.IsRetreating(bot)
	then
		local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( nRadius, true, BOT_MODE_NONE );
		for _,npcEnemy in pairs( tableNearbyEnemyHeroes )
		do
			if ( bot:WasRecentlyDamagedByHero( npcEnemy, 1.0 ) ) 
			then
				return BOT_ACTION_DESIRE_HIGH;
			end
		end
	end
	
	if bot:GetActiveMode() == BOT_MODE_FARM and bot:GetHealth()/bot:GetMaxHealth() < 0.45
	then
		local npcTarget = bot:GetAttackTarget();
		if npcTarget ~= nil then
			return BOT_ACTION_DESIRE_LOW;
		end
	end	
	
	if ( bot:GetActiveMode() == BOT_MODE_ROSHAN  ) 
	then
		local npcTarget = bot:GetTarget();
		if ( mutil.IsRoshan(npcTarget) and mutil.CanCastOnMagicImmune(npcTarget) and mutil.IsInRange(npcTarget, bot, 300)  )
		then
			return BOT_ACTION_DESIRE_LOW;
		end
	end
	
	if mutil.IsInTeamFight(bot, 1200)
	then
		local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( nRadius, true, BOT_MODE_NONE  );
		if ( #tableNearbyEnemyHeroes >= 2 )
		then
			return BOT_ACTION_DESIRE_MODERATE;
		end
	end
	
	-- If we're going after someone
	if  mutil.IsGoingOnSomeone(bot)
	then
		local npcTarget = bot:GetTarget();
		if ( mutil.IsValidTarget(npcTarget) and mutil.CanCastOnNonMagicImmune(npcTarget) and mutil.IsInRange(npcTarget, bot, nRadius-400) ) 
		then
			return BOT_ACTION_DESIRE_HIGH;
		end
	end
	
	return BOT_ACTION_DESIRE_NONE


end



function ConsiderBerserkPotion()

	-- Make sure it's castable
	if ( not abilityBP:IsFullyCastable() or abilityBP:IsHidden() == true  ) then 
		return BOT_ACTION_DESIRE_NONE;
	end
	
	-- Get some of its values
	local nCastRange = abilityBP:GetCastRange();
	
	local tableNearbyFriendlyHeroes = bot:GetNearbyHeroes( 1000, false, BOT_MODE_NONE );
	for _,myFriend in pairs(tableNearbyFriendlyHeroes) 
	do
		if  myFriend:GetUnitName() ~= bot:GetUnitName() and mutil.IsRetreating(myFriend) and
			myFriend:WasRecentlyDamagedByAnyHero(2.0) and mutil.CanCastOnNonMagicImmune(myFriend)
			and not  myFriend:HasModifier("modifier_alchemist_berserk_potion")
		then
			return BOT_ACTION_DESIRE_MODERATE, myFriend;
		end
	end	
	
	
	-- If we're seriously retreating, see if we can land a stun on someone who's damaged us recently
	if mutil.IsRetreating(bot)
	then
		local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( nCastRange, true, BOT_MODE_NONE );
		for _,npcEnemy in pairs( tableNearbyEnemyHeroes )
		do 
			if ( bot:WasRecentlyDamagedByHero( npcEnemy, 2.0 ) and not  bot:HasModifier("modifier_alchemist_berserk_potion")) 
			then
				return BOT_ACTION_DESIRE_HIGH, bot;
			end
		end
	end
	
	
	-- If we're in a teamfight, use it on the protect ally
	if mutil.IsInTeamFight(bot, 1200)
	then
		local lowHpAlly = nil;
		local nLowestHealth = 10000;
		local tableNearbyAllies = bot:GetNearbyHeroes( 1200, false, BOT_MODE_NONE  );
		for _,npcAlly in pairs( tableNearbyAllies )
		do
			if ( npcAlly:GetUnitName() ~= bot:GetUnitName() and mutil.CanCastOnNonMagicImmune(npcAlly) 
			    and not  npcAlly:HasModifier("modifier_alchemist_berserk_potion"))
			then
				local nAllyHP = npcAlly:GetHealth();
				if ( ( nAllyHP < nLowestHealth or npcAlly:GetHealth() / npcAlly:GetMaxHealth() < 0.5 ) or mutil.IsDisabled(false, npcAlly) )
				then
					nLowestHealth = nAllyHP;
					lowHpAlly = npcAlly;
				end
			end
		end

		if ( lowHpAlly ~= nil )
		then
			return BOT_ACTION_DESIRE_MODERATE,lowHpAlly;
		end
	end
	

	-- If we're going after someone
	if mutil.IsGoingOnSomeone(bot)
	then
		local npcTarget = bot:GetTarget(); 
		if mutil.IsValidTarget(npcTarget) and mutil.CanCastOnNonMagicImmune(npcTarget) 
		   and mutil.IsInRange(npcTarget, bot, nCastRange/2) and not  bot:HasModifier("modifier_alchemist_berserk_potion")
		    
		then
			return BOT_ACTION_DESIRE_MODERATE, bot;
		end
	end
	
	

	
	
	return BOT_ACTION_DESIRE_NONE;
end

return X
-- dota2jmz@163.com QQ:2462331592.

