local X = {}
local bot = GetBot()

local J = require( GetScriptDirectory()..'/FunLib/jmz_func')
local ConversionMode = dofile( GetScriptDirectory()..'/AuxiliaryScript/BotlibConversion') --引入技能文件
local Minion = dofile( GetScriptDirectory()..'/FunLib/Minion')
local sTalentList = J.Skill.GetTalentList(bot)
local sAbilityList = J.Skill.GetAbilityList(bot)

--编组技能、天赋、装备
local tGroupedDataList = {
	{
		--组合说明，不影响游戏
		['info'] = 'By Misunderstand',
		['Talent'] = {
			['t25'] = {10, 0},
			['t20'] = {0, 10},
			['t15'] = {0, 10},
			['t10'] = {10, 0},
		},
		['Ability'] = { 1, 3, 3, 2, 3, 6, 2, 3, 2, 2, 6, 1, 1, 1, 6 },
		['Buy'] = {
			"树之祭祀", -- item_tango',
			"力量手套", -- 'item_gauntlets',
			"两个铁树枝干", -- 'item_double_branches',
			"魔杖", -- 'item_magic_wand',
			"护腕", -- 'item_bracer',
			"魔法芒果", -- 'item_enchanted_mango',
			"相位鞋", -- 'item_phase_boots',
			"先锋盾", -- 'item_vanguard',
			"闪烁匕首", -- 'item_blink',
			"挑战头巾", -- 'item_hood_of_defiance',
			"阿哈利姆魔晶", -- 'item_aghanims_shard',
			"辉耀", -- 'item_radiance',
			"洞察烟斗", -- 'item_pipe',
			"赤红甲", -- 'item_crimson_guard',
			"恐鳌之心", -- 'item_heart',
			"盛势闪光", -- 'item_overwhelming_blink',
			"阿哈利姆神杖2", -- 'item_ultimate_scepter_2',
			"远行鞋", -- 'item_travel_boots',
			"银月之晶", -- 'item_moon_shard',
			"远行鞋2" -- 'item_travel_boots_2',
		},
		['Sell'] = {
			"挑战头巾", -- 'item_hood_of_defiance',     
			"护腕", -- 'item_bracer',

			"恐鳌之心", -- 'item_heart',    
			"魔杖", -- 'item_magic_wand',
					
			"远行鞋", -- 'item_travel_boots',
			"相位鞋" -- 'item_phase_boots',
		}
	},
	{
		--组合说明，不影响游戏
		['info'] = 'By 铅笔会有猫的w',
		['Talent'] = {
			['t25'] = {10, 0},
			['t20'] = {10, 0},
			['t15'] = {10, 0},
			['t10'] = {10, 0},
		},
		['Ability'] = { 2, 1, 1, 2, 3, 6, 1, 2, 2, 1, 6, 3, 3, 3, 6},
		['Buy'] = {
			"树之祭祀", -- 'item_tango',
			"治疗药膏", -- 'item_flask',
			"两个魔法芒果", -- 'item_double_enchanted_mango',
			"力量手套", -- 'item_gauntlets',
			"魔棒", -- 'item_magic_stick',
			"护腕", -- 'item_bracer',
			"魔杖", -- 'item_magic_wand',
			"相位鞋", -- 'item_phase_boots',
			"先锋盾", -- 'item_vanguard',
			"挑战头巾", -- 'item_hood_of_defiance', 
			"闪烁匕首", -- 'item_blink',
			"炎阳纹章", -- 'item_solar_crest',
			"阿哈利姆魔晶", -- 'item_aghanims_shard',
			"赤红甲", -- 'item_crimson_guard',
			"阿哈利姆神杖", -- 'item_ultimate_scepter',
			"洞察烟斗", -- 'item_pipe',
			"恐鳌之心", -- 'item_heart',
			"盛势闪光", -- 'item_overwhelming_blink',
			"阿哈利姆神杖2", -- 'item_ultimate_scepter_2',
			"希瓦的守护", -- 'item_shivas_guard',
			"远行鞋2", -- 'item_travel_boots_2',
			"银月之晶" -- 'item_moon_shard',
		},
		['Sell'] = {
			"赤红甲",  -- 'item_crimson_guard',
			"护腕", -- 'item_bracer',

			"阿哈利姆神杖", -- 'item_ultimate_scepter',
			"魔棒", -- 'item_magic_stick',

			"阿哈利姆神杖",   -- 'item_ultimate_scepter',  
			"护腕", -- 'item_bracer',

			"远行鞋2", -- 'item_travel_boots_2',
			"相位鞋" -- 'item_phase_boots',
		}
	},
	{
		--组合说明，不影响游戏
		['info'] = 'Alcedo',
		['Talent'] = {
			['t25'] = {10, 0},
			['t20'] = {10, 0},
			['t15'] = {10, 0},
			['t10'] = {0, 10},
		},
		['Ability'] = { 3, 1, 3, 2, 3, 6, 3, 2, 2, 2, 6, 1, 1, 1, 6},
		['Buy'] = {
			"树之祭祀", -- 'item_tango',
			"压制之刃", -- 'item_quelling_blade',
			"两个魔法芒果", -- 'item_double_enchanted_mango',
			"力量手套", -- 'item_gauntlets',
			"魔棒", -- 'item_magic_stick',
			"护腕", -- 'item_bracer',
			"魔杖", -- 'item_magic_wand',
			"相位鞋", -- 'item_phase_boots',
			"先锋盾", -- 'item_vanguard',
			"挑战头巾", -- 'item_hood_of_defiance', 
			'强袭胸甲', -- 'item_assault',
			-- "恐鳌之戒",
			"碎颅锤", -- 'item_basher',
			"恐鳌之心", -- 'item_heart',
			"希瓦的守护", -- 'item_shivas_guard',
			"阿哈利姆神杖", -- 'item_ultimate_scepter',
			"深渊之刃", -- 'item_abyssal_blade',
			"阿哈利姆神杖2", -- 'item_ultimate_scepter_2',
			"银月之晶" -- 'item_moon_shard',
		},
		['Sell'] = {
			"清莲宝珠", -- 'item_lotus_orb',
			"护腕", -- 'item_bracer',

			"散夜对剑", -- 'item_sange_and_yasha',
			"挑战头巾", -- 'item_hood_of_defiance',

			"远行鞋2", -- 'item_travel_boots_2',
			"相位鞋" -- 'item_phase_boots',
		}
	},
}
--默认数据
local tDefaultGroupedData = {
	['Talent'] = {
		['t25'] = {0, 10},
		['t20'] = {10, 0},
		['t15'] = {0, 10},
		['t10'] = {0, 10},
	},
	['Ability'] = {2,3,1,2,2,6,2,3,3,3,6,1,1,1,6},
	['Buy'] = {
		"树之祭祀", -- 'item_tango',
		"治疗药膏", -- 'item_flask',
		"压制之刃", -- 'item_quelling_blade',
		"魔棒", -- 'item_magic_stick',
		"两个铁树枝干", -- 'item_double_branches',
		"魔杖", -- 'item_magic_wand',
		"先锋盾", -- 'item_vanguard',
		"闪烁匕首", -- 'item_blink',
		"洞察烟斗", -- 'item_pipe',
		"阿哈利姆神杖", -- 'item_ultimate_scepter',
		"恐鳌之心", -- 'item_heart',
		"希瓦的守护", -- 'item_shivas_guard',
	},
	['Sell'] = {
		"魔杖", -- 'item_magic_wand',
		"赤红甲", -- 'item_crimson_guard',
		"先锋盾", -- 'item_vanguard',
	}
}

--根据组数据生成技能、天赋、装备
local nAbilityBuildList, nTalentBuildList;

nAbilityBuildList, nTalentBuildList, X['sBuyList'], X['sSellList'] = ConversionMode.Combination(tGroupedDataList, tDefaultGroupedData, true)

nAbilityBuildList,nTalentBuildList,X['sBuyList'],X['sSellList'] = J.SetUserHeroInit(nAbilityBuildList,nTalentBuildList,X['sBuyList'],X['sSellList']);

X['sSkillList'] = J.Skill.GetSkillList(sAbilityList, nAbilityBuildList, sTalentList, nTalentBuildList)

X['bDeafaultAbility'] = true
X['bDeafaultItem'] = false

function X.MinionThink(hMinionUnit)

	if Minion.IsValidUnit(hMinionUnit) 
	then
		Minion.IllusionThink(hMinionUnit)
	end

end

function X.SkillsComplement()

	--如果当前英雄无法使用技能或英雄处于隐形状态，则不做操作。
	if J.CanNotUseAbility(bot) or bot:IsInvisible() then return end
	--技能检查顺序
	local order = {'Q','W','R'}
	--委托技能处理函数接管
	if ConversionMode.Skills(order) then return; end
	
end

return X
-- dota2jmz@163.com QQ:2462331592
