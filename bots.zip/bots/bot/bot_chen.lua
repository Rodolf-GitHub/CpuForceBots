local MinionUtility = dofile( GetScriptDirectory().."/MinionUtility" )

function  MinionThink(  hMinionUnit ) 
	MinionUtility.MinionThink(hMinionUnit)
end	
