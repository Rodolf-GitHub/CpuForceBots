-----------------
--英雄：卓尔游侠
--技能：霜冻之箭
--键位：Q
--类型：指向目标
--作者：决明子
-----------------
local X = {}
local bot = GetBot()

local J = require( GetScriptDirectory()..'/FunLib/jmz_func')
local U = require( GetScriptDirectory()..'/AuxiliaryScript/Generic')
local utils = require( GetScriptDirectory().."/util")
local mutil = require(GetScriptDirectory().."/MyUtility")
-- local mutils = require(GetScriptDirectory().."/MyUtility")

--初始数据
local ability = bot:GetAbilityByName('nevermore_necromastery')
local nKeepMana, nMP, nHP, nLV, hEnemyHeroList, hAlleyHeroList, aetherRange;

nKeepMana = 90 --魔法储量
nLV = bot:GetLevel(); --当前英雄等级
nMP = bot:GetMana()/bot:GetMaxMana(); --目前法力值/最大法力值（魔法剩余比）
nHP = bot:GetHealth()/bot:GetMaxHealth();--目前生命值/最大生命值（生命剩余比）
hEnemyHeroList = bot:GetNearbyHeroes(1600, true, BOT_MODE_NONE);--1600范围内敌人
hAlleyHeroList = bot:GetNearbyHeroes(1600, false, BOT_MODE_NONE);--1600范围内队友

--获取以太棱镜施法距离加成
local aether = J.IsItemAvailable("item_aether_lens");
if aether ~= nil then aetherRange = 250 else aetherRange = 0 end
    
--初始化函数库
U.init(nLV, nMP, nHP, bot);

--技能释放功能
function X.Release(castTarget)
    if castTarget ~= nil then
        X.Compensation()
        bot:ActionQueue_UseAbilityOnEntity( ability, castTarget ) --使用技能
    end
end

--补偿功能
function X.Compensation()
    J.SetQueuePtToINT(bot, true)--临时补充魔法，使用魂戒
end

--技能释放欲望
function X.Consider()

	-- -- 确保技能可以使用
    -- if ability == nil
	   -- or ability:IsNull()
       -- or not ability:IsFullyCastable()
	   -- or bot:IsDisarmed()
	   -- or J.GetDistanceFromEnemyFountain(bot) < 800
	-- then
		-- return BOT_ACTION_DESIRE_NONE, 0; --没欲望
	-- end
    
  if not bot:HasModifier( 'modifier_item_aghanims_shard' ) 
		or ability == nil
	    or ability:IsNull()
		or not ability:IsFullyCastable()
		or bot:IsDisarmed()
		or J.GetDistanceFromEnemyFountain( bot ) < 800
	then
		return BOT_ACTION_DESIRE_NONE, 0; --没欲望
	end
	
	
	-- -- Get some of its values
	-- local SAStack = 0;
	-- local npcModifier = bot:NumModifiers();
	
	-- for i = 0, npcModifier 
	-- do
		-- if bot:GetModifierName(i) == "modifier_nevermore_necromastery" then
			-- SAStack = bot:GetModifierStackCount(i);
			-- break;
		-- end
	-- end
	
	

	local nAttackRange = bot:GetAttackRange() + 40
	-- local nAttackDamage = bot:GetAttackDamage() + (ability:GetSpecialValueInt( "necromastery_damage_per_soul" ) * SAStack )
	local nAttackDamage = bot:GetAttackDamage() 
	local nDamageType = DAMAGE_TYPE_PHYSICAL
	local nTowers = bot:GetNearbyTowers( 900, true )
	local nEnemysLaneCreepsInRange = bot:GetNearbyLaneCreeps( nAttackRange + 30, true )
	local nEnemysLaneCreepsNearby = bot:GetNearbyLaneCreeps( 400, true )
	local nEnemysWeakestLaneCreepsInRange = J.GetAttackableWeakestUnit( bot, nAttackRange + 30, false, true )
	local nEnemysWeakestLaneCreepsInRangeHealth = 10000
	if( nEnemysWeakestLaneCreepsInRange ~= nil )
	then
		nEnemysWeakestLaneCreepsInRangeHealth = nEnemysWeakestLaneCreepsInRange:GetHealth()
	end

	local nEnemysHeroesInAttackRange = bot:GetNearbyHeroes( nAttackRange, true, BOT_MODE_NONE )
	local nInAttackRangeWeakestEnemyHero = J.GetAttackableWeakestUnit( bot, nAttackRange, true, true )
	local nInViewWeakestEnemyHero = J.GetAttackableWeakestUnit( bot, 800, true, true )

	local nAllyLaneCreeps = bot:GetNearbyLaneCreeps( 330, false )
	local npcTarget = J.GetProperTarget( bot )
	local nTargetUint = nil
	local npcMode = bot:GetActiveMode()

	
	local currManaP = bot:GetMana() / bot:GetMaxMana();
	-- local npcTarget = bot:GetTarget();
	
	if ( npcTarget ~= nil and (npcTarget:IsHero() or npcTarget:GetUnitName() == "npc_dota_roshan" and mutil.CanCastOnNonMagicImmune(npcTarget)   ) and currManaP > .25)   or (bot:GetActiveMode() == BOT_MODE_FARM   and currManaP > .85)
	then
		if not ability:GetAutoCastState( ) then
			ability:ToggleAutoCast()
		end
	else 
		if  ability:GetAutoCastState( ) then
			ability:ToggleAutoCast()
		end
	end

	
	-- if nLV >= 8
	if ( npcTarget ~= nil and (npcTarget:IsHero() or npcTarget:GetUnitName() == "npc_dota_roshan" and mutil.CanCastOnNonMagicImmune(npcTarget)   ) and currManaP > .25)   or (bot:GetActiveMode() == BOT_MODE_FARM   and currManaP > .85)
	then
		if ( hEnemyList[1] ~= nil or nMP > 0.76 )
			and not ability:GetAutoCastState()
		then
			lastAutoTime = DotaTime()
			ability:ToggleAutoCast()
		elseif ( hEnemyList[1] == nil and nMP < 0.7 )
				and lastAutoTime + 3.0 < DotaTime()
				and ability:GetAutoCastState()
			then
				ability:ToggleAutoCast()
		end
	else
		if ability:GetAutoCastState()
		then
			ability:ToggleAutoCast()
		end
	end

	if nLV <= 7 and nHP > 0.55
		and J.IsValidHero( npcTarget )
		and ( not J.IsRunning( bot ) or J.IsInRange( bot, npcTarget, nAttackRange + 18 ) )
	then
		if not npcTarget:IsAttackImmune()
			and J.IsInRange( bot, npcTarget, nAttackRange + 99 )
		then
			nTargetUint = npcTarget
			return BOT_ACTION_DESIRE_HIGH, nTargetUint
		end
	end


	if npcMode == BOT_MODE_LANING
		and #nTowers == 0
	then

		if J.IsValid( nInAttackRangeWeakestEnemyHero )
		then
			if nEnemysWeakestLaneCreepsInRangeHealth > 130
				and nHP >= 0.6
				and #nEnemysLaneCreepsNearby <= 3
				and #nAllyLaneCreeps >= 2
				and not bot:WasRecentlyDamagedByCreep( 1.5 )
				and not bot:WasRecentlyDamagedByAnyHero( 1.5 )
			then
				nTargetUint = nInAttackRangeWeakestEnemyHero
				return BOT_ACTION_DESIRE_HIGH, nTargetUint
			end
		end


		if J.IsValid( nInViewWeakestEnemyHero )
		then
			if nEnemysWeakestLaneCreepsInRangeHealth > 180
				and nHP >= 0.7
				and #nEnemysLaneCreepsNearby <= 2
				and #nAllyLaneCreeps >= 3
				and not bot:WasRecentlyDamagedByCreep( 1.5 )
				and not bot:WasRecentlyDamagedByAnyHero( 1.5 )
				and not bot:WasRecentlyDamagedByTower( 1.5 )
			then
				nTargetUint = nInViewWeakestEnemyHero
				return BOT_ACTION_DESIRE_HIGH, nTargetUint
			end

			if J.GetUnitAllyCountAroundEnemyTarget( nInViewWeakestEnemyHero , 500 ) >= 4
				and not bot:WasRecentlyDamagedByCreep( 1.5 )
				and not bot:WasRecentlyDamagedByAnyHero( 1.5 )
				and not bot:WasRecentlyDamagedByTower( 1.5 )
				and nHP >= 0.6
			then
				nTargetUint = nInViewWeakestEnemyHero
				return BOT_ACTION_DESIRE_HIGH, nTargetUint
			end
		end

		if J.IsWithoutTarget( bot )
			and not J.IsAttacking( bot )
		then
			local nLaneCreepList = bot:GetNearbyLaneCreeps( 1100, true )
			for _, creep in pairs( nLaneCreepList )
			do
				if J.IsValid( creep )
					and not creep:HasModifier( "modifier_fountain_glyph" )
					and creep:GetHealth() < nAttackDamage + 180
					and not J.IsAllysTarget( creep )
				then
					local nAttackProDelayTime = J.GetAttackProDelayTime( bot, nCreep ) * 1.08 + 0.08
					local nAD = nAttackDamage * bot:GetAttackCombatProficiency( creep )
					if J.WillKillTarget( creep, nAD, nDamageType, nAttackProDelayTime )
					then
						return BOT_ACTION_DESIRE_HIGH, creep
					end
				end
			end

		end
	end


	if npcTarget ~= nil
		and npcTarget:IsHero()
		and GetUnitToUnitDistance( npcTarget, bot ) > nAttackRange + 160
		and J.IsValid( nInAttackRangeWeakestEnemyHero )
		and not nInAttackRangeWeakestEnemyHero:IsAttackImmune()
	then
		nTargetUint = nInAttackRangeWeakestEnemyHero
		bot:SetTarget( nTargetUint )
		return BOT_ACTION_DESIRE_HIGH, nTargetUint
	end


	if bot:HasModifier( "modifier_item_hurricane_pike_range" )
		and J.IsValid( npcTarget )
	then
		nTargetUint = npcTarget
		return BOT_ACTION_DESIRE_HIGH, nTargetUint
	end


	if bot:GetAttackTarget() == nil
		and  bot:GetTarget() == nil
		and  #hEnemyList == 0
		and  npcMode ~= BOT_MODE_RETREAT
		and  npcMode ~= BOT_MODE_ATTACK
		and  npcMode ~= BOT_MODE_ASSEMBLE
		and  npcMode ~= BOT_MODE_FARM
		and  npcMode ~= BOT_MODE_TEAM_ROAM
		and  J.GetTeamFightAlliesCount( bot ) < 3
		and  bot:GetMana() >= 180
		and  not bot:WasRecentlyDamagedByAnyHero( 3.0 )
	then

		if bot:HasScepter()
		then
			local nEnemysCreeps = bot:GetNearbyCreeps( 1600, true )
			if J.IsValid( nEnemysCreeps[1] ) 
			-- and SAStack >= 11 
			then
				nTargetUint = nEnemysCreeps[1]
				return BOT_ACTION_DESIRE_HIGH, nTargetUint
			end
		end

		local nNeutralCreeps = bot:GetNearbyNeutralCreeps( 1600 )
		if npcMode ~= BOT_MODE_LANING
			and nLV >= 6
			and nHP > 0.25
			and J.IsValid( nNeutralCreeps[1] )
			and not J.IsRoshan( nNeutralCreeps[1] )
			and ( nNeutralCreeps[1]:IsAncientCreep() == false or nLV >= 12 )
			-- and SAStack >= 11 
		then
			nTargetUint = nNeutralCreeps[1]
			return BOT_ACTION_DESIRE_HIGH, nTargetUint
		end


		local nLaneCreeps = bot:GetNearbyLaneCreeps( 1600, true )
		if npcMode ~= BOT_MODE_LANING
			and nLV >= 6
			and nHP > 0.25
			and J.IsValid( nLaneCreeps[1] )
			and bot:GetAttackDamage() > 130
			-- and SAStack >= 11 
		then
			nTargetUint = nLaneCreeps[1]
			return BOT_ACTION_DESIRE_HIGH, nTargetUint
		end
	end


	if npcMode == BOT_MODE_RETREAT
	then

		nDistance = 999
		local nTargetUint = nil
		for _, npcEnemy in pairs( nEnemysHeroesInAttackRange )
		do
			if J.IsValid( npcEnemy )
				-- and npcEnemy:HasModifier( "modifier_drowranger_wave_of_silence_knockback" )
				
				and GetUnitToUnitDistance( npcEnemy, bot ) < nDistance
			then
				nTargetUint = npcEnemy
				nDistance = GetUnitToUnitDistance( npcEnemy, bot )
			end
		end

		if nTargetUint ~= nil and nHP > 0.25
			-- and not nTargetUint:HasModifier( "modifier_drow_ranger_frost_arrows_slow" )
		then
			return BOT_ACTION_DESIRE_HIGH, nTargetUint
		end
	end

	if J.IsFarming( bot )
		and nMP > 0.55
		and not ability:GetAutoCastState()
	then
		if J.IsValid( botTarget )
			and botTarget:GetTeam() == TEAM_NEUTRAL
			and J.IsInRange( bot, botTarget, 1000 )
			and botTarget:GetHealth() > nAttackDamage
		then
			return BOT_ACTION_DESIRE_HIGH, botTarget
		end
	end
	
	
	
	
	-- If we're going after someone
	if J.IsGoingOnSomeone(bot)
	then
		local npcTarget = bot:GetTarget();
		if J.IsValidHero(npcTarget) and J.CanCastOnNonMagicImmune(npcTarget) and J.IsInRange(npcTarget, bot, nAttackRange+200) and
		   not J.IsDisabled(npcTarget)
		then
			-- local cpos = utils.GetTowardsFountainLocation(npcTarget:GetLocation(), 0);
					-- bot:ActionImmediate_Ping( cpos.x,  cpos.y, true)
			return BOT_ACTION_DESIRE_HIGH, npcTarget;
		end
	end
	
    
	
	return BOT_ACTION_DESIRE_NONE, 0;
	
end

return X;