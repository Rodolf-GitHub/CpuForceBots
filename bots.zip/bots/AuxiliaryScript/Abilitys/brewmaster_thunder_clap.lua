-----------------
--英雄：酒仙
--技能：雷霆一击
--键位：Q
--类型：无目标
--作者：Меня завут Зона!
-----------------
local X = {}
local bot = GetBot()

local J = require( GetScriptDirectory()..'/FunLib/jmz_func')
local U = require( GetScriptDirectory()..'/AuxiliaryScript/Generic')

local utils = require( GetScriptDirectory().."/util")
local mutil = require(GetScriptDirectory().."/MyUtility")
-- local mutils = require(GetScriptDirectory().."/MyUtility")

--初始数据
local ability = bot:GetAbilityByName('brewmaster_thunder_clap')
local nKeepMana, nMP, nHP, nLV, hEnemyHeroList, hAlleyHeroList;


nKeepMana = 180 --魔法储量
nLV = bot:GetLevel(); --当前英雄等级
nMP = bot:GetMana()/bot:GetMaxMana(); --目前法力值/最大法力值（魔法剩余比）
nHP = bot:GetHealth()/bot:GetMaxHealth();--目前生命值/最大生命值（生命剩余比）
hEnemyHeroList = bot:GetNearbyHeroes(1600, true, BOT_MODE_NONE);--1600范围内敌人
hAlleyHeroList = bot:GetNearbyHeroes(1600, false, BOT_MODE_NONE);--1600范围内队友

--初始化函数库
U.init(nLV, nMP, nHP, bot);

--技能释放功能
function X.Release(castTarget)
    X.Compensation() 
    bot:ActionQueue_UseAbility( ability ) --使用技能
end

--补偿功能
function X.Compensation()
    J.SetQueuePtToINT(bot, true)--临时补充魔法，使用魂戒
end

--技能释放欲望
function X.Consider()
	-- 确保技能可以使用
    if ability == nil
	   or ability:IsNull()
       or not ability:IsFullyCastable()
	then 
		return BOT_ACTION_DESIRE_NONE, 0; --没欲望
	end

    -- Get some of its values
	local nRadius = ability:GetSpecialValueInt( "radius" );
	local nCastRange = 0;
	local nDamage = ability:GetSpecialValueInt("damage");
	
	--------------------------------------
	-- Mode based usage
	--------------------------------------
	
	local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( nRadius - 100, true, BOT_MODE_NONE );
	
	--if we can kill any enemies
	for _,npcEnemy in pairs(tableNearbyEnemyHeroes)
	do
		if mutil.CanCastOnNonMagicImmune(npcEnemy) and mutil.CanKillTarget(npcEnemy, nDamage, DAMAGE_TYPE_MAGICAL) then
			return BOT_ACTION_DESIRE_HIGH;
		end
	end
	
	
	-- If there is any ally seriously retreating, see if we can land a stun on someone who's damaged our ally recently
	if #hAlleyHeroList >=1 then
		for _,ally in pairs( hAlleyHeroList )
		do
	
		if J.IsRetreating(ally)
		 then
			local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( 1200, true, BOT_MODE_NONE );
		for _,npcEnemy in pairs( tableNearbyEnemyHeroes )
		do
			if ( ally:WasRecentlyDamagedByHero( npcEnemy, 2.0 ) and J.CanCastOnNonMagicImmune(npcEnemy) and J.IsInRange(npcEnemy, bot, nRadius - 100)   ) 
			then
				return BOT_ACTION_DESIRE_MODERATE;
			end
		end
	end
	end
	end
	
	

	-- If we're seriously retreating, see if we can land a stun on someone who's damaged us recently
	if J.IsRetreating(bot)
	then
		local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( nRadius, true, BOT_MODE_NONE );
		for _,npcEnemy in pairs( tableNearbyEnemyHeroes )
		do
			if ( bot:WasRecentlyDamagedByHero( npcEnemy, 2.0 ) and J.CanCastOnNonMagicImmune(npcEnemy)  ) 
			then
				return BOT_ACTION_DESIRE_MODERATE;
			end
		end
	end
	
	if ( bot:GetActiveMode() == BOT_MODE_ROSHAN  ) 
	then
		local npcTarget = bot:GetAttackTarget();
		if ( J.IsRoshan(npcTarget) and J.CanCastOnMagicImmune(npcTarget) and J.IsInRange(npcTarget, bot, nRadius)  )
		then
			return BOT_ACTION_DESIRE_LOW;
		end
	end
	
	-- If we're farming and can kill 3+ creeps with LSA
	if ( mutil.IsPushing(bot) or mutil.IsDefending(bot) or bot:GetActiveMode() == BOT_MODE_LANING ) and nMP > 0.65
	then
		local tableNearbyEnemyCreeps = bot:GetNearbyLaneCreeps( nRadius, true );
		local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( nRadius/2, true, BOT_MODE_NONE );
		if ( tableNearbyEnemyCreeps ~= nil and #tableNearbyEnemyCreeps >= 4 ) then
		
		for _,creeps in pairs(tableNearbyEnemyCreeps)
				do
				if #tableNearbyEnemyHeroes >= 0 and  creeps:HasModifier("modifier_brewmaster_cinder_brew") 
				then
			return BOT_ACTION_DESIRE_LOW;
			
		end
	end
	end
	end
	
	if J.IsInTeamFight( bot, 1200 )
	then
		local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( nRadius - 100, true, BOT_MODE_NONE )
		for _, npcEnemy in pairs( tableNearbyEnemyHeroes )
		do
			if J.CanCastOnNonMagicImmune( npcEnemy )
				and J.CanCastOnTargetAdvanced( npcEnemy )
				-- and J.Role.IsCarry( npcEnemy:GetUnitName() )
				-- and not npcEnemy:HasModifier( 'modifier_bloodseeker_bloodrage' )
				and not J.IsDisabled( npcEnemy )
			then
				return BOT_ACTION_DESIRE_HIGH;
			end
		end
	end
	
	if bot:GetActiveMode() == BOT_MODE_FARM  and nMP > 0.45
	then
		local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( 1300, true, BOT_MODE_NONE );
		local tableNearbyNeutrals = bot:GetNearbyNeutralCreeps( nRadius - 100 );
			if tableNearbyNeutrals ~= nil and #tableNearbyNeutrals >= 2 then
				for _,neutral in pairs(tableNearbyNeutrals)
				do
				if #tableNearbyEnemyHeroes == 0 and  neutral:HasModifier("modifier_brewmaster_cinder_brew")
					then 
					return BOT_ACTION_DESIRE_MODERATE;
				end
			end
		end
	end
	
	
	
	
	-- If we're going after someone
	if J.IsGoingOnSomeone(bot)
	then
		local npcTarget = bot:GetTarget();
		if J.IsValidHero(npcTarget) and J.CanCastOnNonMagicImmune(npcTarget) and J.IsInRange(npcTarget, bot, nRadius - 100)
		then
			local cpos = utils.GetTowardsFountainLocation(npcTarget:GetLocation(), 0);
				bot:ActionImmediate_Ping( cpos.x,  cpos.y, true)
			return BOT_ACTION_DESIRE_VERYHIGH;
		end
	end
	
	
	
	
	
	
    return BOT_ACTION_DESIRE_NONE;
    
end

return X;