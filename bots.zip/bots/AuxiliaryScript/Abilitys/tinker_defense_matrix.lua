-----------------
--英雄：修补匠
--技能：激光
--键位：Q
--类型：指向单位
--作者：Меня завут Зона!
-----------------
local X = {}
local bot = GetBot()

local J = require( GetScriptDirectory()..'/FunLib/jmz_func')
local U = require( GetScriptDirectory()..'/AuxiliaryScript/Generic')
local utils = require( GetScriptDirectory().."/util")
-- local mutil = require(GetScriptDirectory().."/MyUtility")
local mutils = require(GetScriptDirectory().."/MyUtility")

--初始数据
local ability = bot:GetAbilityByName('tinker_defense_matrix')
local nKeepMana, nMP, nHP, nLV, hEnemyHeroList, hAlleyHeroList;
local lastCheck = -90;

nKeepMana = 180 --魔法储量
nLV = bot:GetLevel(); --当前英雄等级
nMP = bot:GetMana()/bot:GetMaxMana(); --目前法力值/最大法力值（魔法剩余比）
nHP = bot:GetHealth()/bot:GetMaxHealth();--目前生命值/最大生命值（生命剩余比）
hEnemyHeroList = bot:GetNearbyHeroes(1600, true, BOT_MODE_NONE);--1600范围内敌人
hAlleyHeroList = bot:GetNearbyHeroes(1600, false, BOT_MODE_NONE);--1600范围内队友

--初始化函数库
U.init(nLV, nMP, nHP, bot);

--技能释放功能
function X.Release(castTarget)
    if castTarget ~= nil then
        X.Compensation()
        bot:ActionQueue_UseAbilityOnEntity( ability, castTarget ) --使用技能
    end
end

--补偿功能
function X.Compensation()
    J.SetQueuePtToINT(bot, true)--临时补充魔法，使用魂戒
end

--技能释放欲望
function X.Consider()
	-- 确保技能可以使用
    if ability == nil
	   or ability:IsNull()
       or not ability:IsFullyCastable()
	   or ability:IsHidden() 
	   or bot:HasModifier('modifier_item_aghanims_shard') == false 
	then 
		return BOT_ACTION_DESIRE_NONE, 0; --没欲望
	end

	-----------------------------------------
	
  	local nCastRange = mutils.GetProperCastRange(false, bot, ability:GetCastRange());
	local nCastPoint = ability:GetCastPoint();
	local manaCost   = ability:GetManaCost();
	
	if mutils.IsRetreating(bot) and bot:HasModifier('modifier_tinker_defense_matrix') == false and mutils.CanCastOnNonMagicImmune(bot) 
	then
		local enemies = bot:GetNearbyHeroes(1200, true, BOT_MODE_NONE);
		if #enemies > 0 and bot:GetHealth() <= (0.2+(#enemies*0.1))*bot:GetMaxHealth() then
			local cpos = utils.GetTowardsFountainLocation( bot:GetLocation(), 0);
				bot:ActionImmediate_Ping( cpos.x,  cpos.y, true)
			return BOT_ACTION_DESIRE_HIGH, bot;
		end
	end

	if mutils.IsInTeamFight(bot, 1200) then
		local allies = bot:GetNearbyHeroes(nCastRange, false, BOT_MODE_NONE);
		local target = nil;
		local maxOP = 0;
		local allies = bot:GetNearbyHeroes(nCastRange, false, BOT_MODE_NONE);
		if #allies > 0 then
			for i=1,#allies do
				if mutils.CanCastOnNonMagicImmune(allies[i])
				   and allies[i]:GetAttackTarget() ~= nil	
				   and allies[i]:GetRawOffensivePower() >= maxOP
				then
					target = allies[i];
					maxOP = allies[i]:GetRawOffensivePower();
				end
			end
		end
		if target == nil then
			local minHP = 100000;
			if #allies > 0 then
				for i=1,#allies do
					if mutils.CanCastOnNonMagicImmune(allies[i])
					   and mutils.IsDisabled(false, allies[i])	
					   and allies[i]:GetHealth() <= minHP
					then
						target = allies[i];
						minHP = allies[i]:GetHealth();
					end
				end
			end
		end
		if target ~= nil then
			return BOT_ACTION_DESIRE_HIGH, target;
		end
	end
	
	if DotaTime() >= lastCheck + 2.0 then 
		local weakest = nil;
		local minHP = 100000;
		local allies = bot:GetNearbyHeroes(nCastRange, false, BOT_MODE_NONE);
		if #allies > 0 then
			for i=1,#allies do
				if (( mutils.CanCastOnNonMagicImmune(allies[i]) and allies[i]:WasRecentlyDamagedByAnyHero(2.0) and allies[i]:GetAttackTarget() == nil )
				   or ( allies[i]:GetHealth() <= minHP and allies[i]:GetHealth() <= 0.55*allies[i]:GetMaxHealth() )
				   and allies[i]:HasModifier('modifier_tinker_defense_matrix') == false )
				then
					weakest = allies[i];
					minHP = allies[i]:GetHealth();
				end
			end
		end
		if weakest ~= nil then
			return BOT_ACTION_DESIRE_HIGH, weakest;
		end
		lastCheck = DotaTime();
	end
	
	return BOT_ACTION_DESIRE_NONE, 0;
end

return X;