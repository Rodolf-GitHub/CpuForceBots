-----------------
--英雄：半人马战行者
--技能：马蹄践踏
--键位：Q
--类型：无目标
--作者：Halcyon
-----------------
local X = {}
local bot = GetBot()

local J = require( GetScriptDirectory()..'/FunLib/jmz_func')
local U = require( GetScriptDirectory()..'/AuxiliaryScript/Generic')

--初始数据
local ability = bot:GetAbilityByName('centaur_hoof_stomp')
local nKeepMana, nMP, nHP, nLV, hEnemyHeroList, hAlleyHeroList;

local utils = require( GetScriptDirectory().."/util")
local mutil = require(GetScriptDirectory().."/MyUtility")
-- local mutils = require(GetScriptDirectory().."/MyUtility")

nKeepMana = 180 --魔法储量
nLV = bot:GetLevel(); --当前英雄等级
nMP = bot:GetMana()/bot:GetMaxMana(); --目前法力值/最大法力值（魔法剩余比）
nHP = bot:GetHealth()/bot:GetMaxHealth();--目前生命值/最大生命值（生命剩余比）
hEnemyHeroList = bot:GetNearbyHeroes(1600, true, BOT_MODE_NONE);--1600范围内敌人
hAlleyHeroList = bot:GetNearbyHeroes(1600, false, BOT_MODE_NONE);--1600范围内队友

--初始化函数库
U.init(nLV, nMP, nHP, bot);

--技能释放功能
function X.Release(castTarget)
    X.Compensation() 
    bot:ActionQueue_UseAbility( ability ) --使用技能
end

--补偿功能
function X.Compensation()
    J.SetQueuePtToINT(bot, true)--临时补充魔法，使用魂戒
end

--技能释放欲望
function X.Consider()
	-- 确保技能可以使用
    if ability == nil
	   or ability:IsNull()
       or not ability:IsFullyCastable()
	then 
		return BOT_ACTION_DESIRE_NONE, 0; --没欲望
	end

    -- Get some of its values
	local nRadius = ability:GetSpecialValueInt( "radius" );
	local nCastRange = 0;
	local nDamage = ability:GetSpecialValueInt( "stomp_damage" );
	local nSkillLV    = ability:GetLevel();
	local nDamageType = DAMAGE_TYPE_MAGICAL;
	local nManaCost = ability:GetManaCost()
	--------------------------------------
	-- Mode based usage
	--------------------------------------

	-- If a mode has set a target, and we can kill them, do it
	local npcTarget = bot:GetTarget();
	if J.IsValidHero(npcTarget) and J.CanCastOnNonMagicImmune(npcTarget) and J.CanKillTarget(npcTarget, nDamage, DAMAGE_TYPE_MAGICAL) and 
	   J.IsInRange(npcTarget, bot, nRadius - 100) 
	then   
		return BOT_ACTION_DESIRE_MODERATE;
	end
	
	if ( bot:GetActiveMode() == BOT_MODE_ROSHAN  ) 
	then
		local npcTarget = bot:GetAttackTarget();
		if ( J.IsRoshan(npcTarget) and J.CanCastOnMagicImmune(npcTarget) and J.IsInRange(npcTarget, bot, nRadius)  )
		then
			return BOT_ACTION_DESIRE_LOW;
		end
	end
	
	-- If we're seriously retreating, see if we can land a stun on someone who's damaged us recently
	if J.IsRetreating(bot)
	then
		local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( nRadius, true, BOT_MODE_NONE );
		for _,npcEnemy in pairs( tableNearbyEnemyHeroes )
		do
			if ( bot:WasRecentlyDamagedByHero( npcEnemy, 2.0 ) and J.CanCastOnNonMagicImmune(npcEnemy) ) 
			then
				return BOT_ACTION_DESIRE_HIGH;
			end
		end
	end

	-- If we're going after someone
	if J.IsGoingOnSomeone(bot)
	then
		if J.IsValidHero(npcTarget) and J.CanCastOnNonMagicImmune(npcTarget) and 
	       J.IsInRange(npcTarget, bot, nRadius - 100) and not J.IsDisabled(npcTarget)
		then  
			local cpos = utils.GetTowardsFountainLocation(npcTarget:GetLocation(), 0);
				bot:ActionImmediate_Ping( cpos.x,  cpos.y, true)
			return BOT_ACTION_DESIRE_HIGH;
		end
	end
	
	
	
	
	 if J.IsFarming(bot) 
		-- and nSkillLV >= 3
		and (bot:GetAttackDamage() < 200 or nMP > 0.88)
		and nMP > 0.71
		-- and nHP > 0.50
	then
		local nCreeps = bot:GetNearbyNeutralCreeps(nRadius - 100);
		
		local targetCreep = J.GetMostHpUnit(nCreeps);
		
		if J.IsValid(targetCreep)
			and ( #nCreeps >= 2 or GetUnitToUnitDistance(targetCreep,bot) <= nRadius - 100 )
			and not J.IsRoshan(targetCreep)
			and not J.IsOtherAllysTarget(targetCreep)
			and targetCreep:GetMagicResist() < 0.3
			and not J.CanKillTarget(targetCreep,bot:GetAttackDamage() *1.68,DAMAGE_TYPE_PHYSICAL)
			and not J.CanKillTarget(targetCreep,nDamage,nDamageType)
		then
			return BOT_ACTION_DESIRE_HIGH;
	    end
	end
	
	
	
	--带线时嘲讽小兵攻击自己
	if ( J.IsPushing( bot ) or J.IsDefending( bot ) or J.IsFarming( bot ) )
		and J.IsAllowedToSpam( bot, nManaCost )
		and bot:GetAttackTarget() ~= nil
		and DotaTime() > 6 * 60
		and #hAlleyHeroList <= 2 
		and #hEnemyHeroList == 0
	then
		local laneCreepList = bot:GetNearbyLaneCreeps( nRadius - 100, true )
		if laneCreepList == nil then laneCreepList = bot:GetNearbyNeutralCreeps(nRadius - 100); return end
		if #laneCreepList >= 3
			and not laneCreepList[1]:HasModifier( "modifier_fountain_glyph" )
		then
			
			return BOT_ACTION_DESIRE_HIGH
		end
	end
	
	
	
	if ( mutil.IsPushing(bot) or mutil.IsDefending(bot) or  bot:GetActiveMode() == BOT_MODE_LANING) 
	or mutil.IsRetreating(bot)   
	then
		local tableNearbyEnemyHeroes = bot:GetNearbyHeroes(1400, true, BOT_MODE_NONE);
		local allies = bot:GetNearbyHeroes(1200, false, BOT_MODE_NONE);
		local Atowers = bot:GetNearbyTowers(1400, false);
		
		for _,npcEnemy in pairs( tableNearbyEnemyHeroes )
		do
			if  mutil.CanCastOnNonMagicImmune(npcEnemy)
			then	
		for _,u in pairs(Atowers) do
			if GetUnitToLocationDistance(bot,u:GetLocation()) <= 700 and GetUnitToLocationDistance(npcEnemy,u:GetLocation()) <= 700
			and J.IsInRange(npcEnemy,bot, nRadius - 100)
				then
			if #allies >= 0 then
			
					return BOT_ACTION_DESIRE_MODERATE;
				end
			end
		end
	end
	end
	end
	
	
	local skThere, skLoc = J.IsSandKingThere(bot, nRadius - 100, 2.0);
	
	if skThere then
			
		return BOT_ACTION_DESIRE_MODERATE;
	end
	
	

    return BOT_ACTION_DESIRE_NONE;
    
end

return X;