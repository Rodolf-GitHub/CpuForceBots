-----------------
--英雄：育母蜘蛛
--技能：孵化蜘蛛
--键位：Q
--类型：指向目标
--作者：Меня завут Зона!
-----------------
local X = {}
local bot = GetBot()

local J = require( 'bots/FunLib/jmz_func')
local U = require('bots/AuxiliaryScript/Generic')
local utils = require( GetScriptDirectory().."/util")
local mutil = require(GetScriptDirectory().."/MyUtility")
-- local mutils = require(GetScriptDirectory().."/MyUtility")

--初始数据
local ability = bot:GetAbilityByName('broodmother_silken_bola')
local nKeepMana, nMP, nHP, nLV, hEnemyHeroList, hAlleyHeroList, aetherRange;

nKeepMana = 120 --魔法储量
nLV = bot:GetLevel(); --当前英雄等级
nMP = bot:GetMana()/bot:GetMaxMana(); --目前法力值/最大法力值（魔法剩余比）
nHP = bot:GetHealth()/bot:GetMaxHealth();--目前生命值/最大生命值（生命剩余比）
hEnemyHeroList = bot:GetNearbyHeroes(1600, true, BOT_MODE_NONE);--1600范围内敌人
hAlleyHeroList = bot:GetNearbyHeroes(1600, false, BOT_MODE_NONE);--1600范围内队友

--获取以太棱镜施法距离加成
local aether = J.IsItemAvailable("item_aether_lens");
if aether ~= nil then aetherRange = 250 else aetherRange = 0 end
    
--初始化函数库
U.init(nLV, nMP, nHP, bot);

--技能释放功能
function X.Release(castTarget)
    if castTarget ~= nil then
        X.Compensation()
		local typeAOE = X.CheckFlag(ability:GetBehavior(), ABILITY_BEHAVIOR_POINT);
		if typeAOE == true then
			bot:ActionQueue_UseAbilityOnLocation( ability, castTarget:GetLocation() );
		else
			bot:ActionQueue_UseAbilityOnEntity( ability, castTarget );
		end
		
        -- bot:ActionQueue_UseAbilityOnEntity( ability, castTarget ) --使用技能
    end
end

--补偿功能
function X.Compensation()
    J.SetQueuePtToINT(bot, true)--临时补充魔法，使用魂戒
end

--技能释放欲望
function X.Consider()

	-- 确保技能可以使用
    if ability == nil
	   or ability:IsNull()
       or not ability:IsFullyCastable()
	then
		return BOT_ACTION_DESIRE_NONE, 0; --没欲望
	end
	
	-- Get some of its values
	local nCastRange = ability:GetCastRange();
	local nDamage = ability:GetSpecialValueInt( "impact_damage" );
	local currManaP = bot:GetMana() / bot:GetMaxMana();

	--------------------------------------
	-- Mode based usage
	--------------------------------------

	-- Check for a channeling enemy
	local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( nCastRange + 200, true, BOT_MODE_NONE );
	for _,npcEnemy in pairs( tableNearbyEnemyHeroes )
	do
		if ( npcEnemy:IsChanneling() and mutil.CanCastOnNonMagicImmune2(npcEnemy) and not mutil.IsSuspiciousIllusion2(npcEnemy) ) 
		then
			return BOT_ACTION_DESIRE_HIGH, npcEnemy;
		end
	end
	
	--if we can kill any enemies
	local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( nCastRange + 200, true, BOT_MODE_NONE );
	for _,npcEnemy in pairs(tableNearbyEnemyHeroes)
	do
		if (mutil.CanCastOnNonMagicImmune2(npcEnemy) and mutil.CanKillTarget2(npcEnemy, nDamage*2, DAMAGE_TYPE_MAGICAL)
		and ability:IsTrained())  
		then
			return BOT_ACTION_DESIRE_HIGH, npcEnemy;
		end
	end
	
	if ( bot:GetActiveMode() == BOT_MODE_ROSHAN  ) 
	then
		local npcTarget = bot:GetAttackTarget();
		if ( mutil.IsRoshan(npcTarget) and mutil.CanCastOnMagicImmune(npcTarget) and mutil.IsInRange(npcTarget, bot, nCastRange)  )
		then
			return BOT_ACTION_DESIRE_LOW, npcTarget;
		end
	end
	
	if ( mutil.IsPushing(bot) or  mutil.IsDefending(bot) or bot:GetActiveMode() == BOT_MODE_LANING) 
	and currManaP > 0.70 and  ability:GetLevel() > 1
	then
	   
	
		local laneCreeps = bot:GetNearbyLaneCreeps(nCastRange, true);
		for _,creep in pairs(laneCreeps)
		do
			if creep:GetHealth() <= nDamage then
			local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( nCastRange, true, BOT_MODE_NONE );
			for _,npcEnemy in pairs(tableNearbyEnemyHeroes)
			do
			if mutil.CanCastOnNonMagicImmune2(npcEnemy) then
				return BOT_ACTION_DESIRE_HIGH, npcEnemy;
				end
			end
		    end
        end
	end
	
	if bot:GetActiveMode() == BOT_MODE_FARM and currManaP > 0.45
	then
		local npcTarget = bot:GetAttackTarget();
		if npcTarget ~= nil and not npcTarget:IsBuilding() then
			return BOT_ACTION_DESIRE_MODERATE,npcTarget;
		end
	end
	
	if ( mutil.IsPushing(bot) or mutil.IsDefending(bot) or bot:GetActiveMode() == BOT_MODE_LANING) 
	and currManaP > 0.45 and  ability:GetLevel() > 1
	then
	   local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( nCastRange + 200, true, BOT_MODE_NONE );
		local tableNearbyAlliedHeroes = bot:GetNearbyHeroes( nCastRange, false, BOT_MODE_NONE );
		for _,npcEnemy in pairs( tableNearbyEnemyHeroes )
		do
			if ( mutil.CanCastOnNonMagicImmune(npcEnemy) and not mutil.IsDisabled(true, npcEnemy)
			and npcEnemy:GetHealth()/npcEnemy:GetMaxHealth() < 0.80 ) and #tableNearbyAlliedHeroes >=1
			then
				
				return BOT_ACTION_DESIRE_HIGH, npcEnemy;
			end
		end
		
	end
	
	-- If we're seriously retreating, see if we can land a stun on someone who's damaged us recently
	if mutil.IsRetreating(bot)
	then
		local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( nCastRange, true, BOT_MODE_NONE );
		for _,npcEnemy in pairs( tableNearbyEnemyHeroes )
		do
			if ( bot:WasRecentlyDamagedByHero( npcEnemy, 2.0 ) and mutil.CanCastOnNonMagicImmune(npcEnemy)  ) 
			then
				
				return BOT_ACTION_DESIRE_HIGH, npcEnemy;
			end
		end
	end
	
	
	if J.IsInTeamFight(bot, 1300)
	then
		local target = J.GetVulnerableWeakestUnit(bot, true, true, nCastRange);
		if target ~= nil and not mutil.IsSuspiciousIllusion(target)then
			return BOT_ACTION_DESIRE_HIGH, target;
		end
	end
	
	

	-- If we're going after someone
	if mutil.IsGoingOnSomeone(bot)
	then
		local npcTarget = bot:GetTarget();
		if mutil.IsValidTarget(npcTarget) and mutil.CanCastOnNonMagicImmune(npcTarget) and mutil.IsInRange(npcTarget, bot, nCastRange+200)
		   and not mutil.IsDisabled(true, npcTarget) and not mutil.IsSuspiciousIllusion(npcTarget)
		then
			local cpos = utils.GetTowardsFountainLocation( npcTarget:GetLocation(), 0);
				bot:ActionImmediate_Ping( cpos.x,  cpos.y, true)
			return BOT_ACTION_DESIRE_HIGH, npcTarget;
		end
	end
	
	
	
	
	-- If there is any ally seriously retreating, see if we can land a stun on someone who's damaged our ally recently
	-- local hAlleyHeroList = bot:GetNearbyHeroes(1600, false, BOT_MODE_NONE);--1600范围内队友
	
	if #hAlleyHeroList >=1 then
		for _,ally in pairs( hAlleyHeroList )
		do
	
		if J.IsRetreating(ally)
		 then
			local tableNearbyEnemyHeroes = bot:GetNearbyHeroes( 1200, true, BOT_MODE_NONE );
		for _,npcEnemy in pairs( tableNearbyEnemyHeroes )
		do
			if ( ally:WasRecentlyDamagedByHero( npcEnemy, 2.0 ) and J.CanCastOnNonMagicImmune(npcEnemy) and J.IsInRange(ally, bot, nCastRange)   ) 
			then
				return BOT_ACTION_DESIRE_MODERATE, npcEnemy;
			end
		end
	end
	end
	end
	
	
	
	return BOT_ACTION_DESIRE_NONE, 0;
	
end


function X.CheckFlag(bitfield, flag)
    return ((bitfield/flag) % 2) >= 1;
end

-- function X.GetDistance(s, t)
    -- if s == nil or t == nil then return end
    -- --print("S1: "..s[1]..", S2: "..s[2].." :: T1: "..t[1]..", T2: "..t[2]);
    -- return math.sqrt((s[1]-t[1])*(s[1]-t[1]) + (s[2]-t[2])*(s[2]-t[2]));
-- end


return X;